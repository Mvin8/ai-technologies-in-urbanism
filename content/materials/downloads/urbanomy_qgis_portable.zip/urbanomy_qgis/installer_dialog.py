"""Install an isolated calculation environment without blocking QGIS's UI.

Only Qt and the standard library are imported by this module. QGIS 3.4 can
therefore run the installer with its own Python 3.6 while a separate Python
3.11 creates and populates the calculation environment.
"""

import json
import os
import tempfile

from qgis.PyQt.QtCore import QProcess, QProcessEnvironment, QTimer, QUrl, Qt
from qgis.PyQt.QtGui import QDesktopServices
from qgis.PyQt.QtWidgets import (
    QComboBox,
    QDialog,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QVBoxLayout,
    QWidget,
)

from .install_support import (
    default_environment_directory,
    environment_python,
    environment_directory,
    executable_candidates,
    mark_installation,
    read_installation_marker,
    validate_install_directory,
)


PYTHON_DOWNLOAD_URL = "https://www.python.org/downloads/release/python-3119/"
PROBE_SCRIPT = (
    "import json, struct, sys, venv, ensurepip; "
    "print(json.dumps({'version': list(sys.version_info[:3]), "
    "'bits': struct.calcsize('P') * 8, 'executable': sys.executable}))"
)
VERIFY_SCRIPT = (
    "import catboost, geopandas, numpy, pandas, pymoo, shapely, pyproj; "
    "from urbanomy.methods.land_value_modeling import "
    "LandPriceEstimator, ScenarioTEPModifier, DistrictProblem, StrategicAlignmentScorer; "
    "from urbanomy.methods.investment_potential import calculate_investment_metrics; "
    "import urbanomy.qgis_backend; "
    "print('URBANOMY_ENVIRONMENT_READY')"
)


class InstallerDialog(QDialog):
    """Discover Python, create a venv and install the bundled requirements."""

    def __init__(self, parent, plugin_directory, configured_python=""):
        super(InstallerDialog, self).__init__(parent)
        self.setWindowTitle("Установка Urbanomy")
        self.resize(600, 260)
        self._plugin_directory = os.path.abspath(plugin_directory)
        self._configured_python = configured_python
        self._python_path = ""
        self._bootstrap_python = ""
        self._venv_directory = ""
        self._backend_directory = ""
        self._requirements_path = ""
        self._reuse_environment = False
        self._busy = False
        self._closing = False
        self._phase = ""
        self._output = b""
        self._timed_out = False
        self._candidates = []
        self.process = None
        self._probe_timer = QTimer(self)
        self._probe_timer.setSingleShot(True)
        self._probe_timer.timeout.connect(self._probe_timeout)

        layout = QVBoxLayout(self)
        description = QLabel(
            "Выберите папку установки. Окружение и библиотеки для расчётов будут настроены автоматически."
        )
        description.setWordWrap(True)
        layout.addWidget(description)

        form = QFormLayout()
        self.bootstrap_python = QComboBox(self)
        self.bootstrap_python.setEditable(True)
        self.bootstrap_python.setToolTip(
            "Отдельный Python 3.11. Python, встроенный в QGIS 3.4, для создания "
            "этого окружения не подходит."
        )
        if configured_python:
            self.bootstrap_python.addItem(str(configured_python))
        self.bootstrap_python.setVisible(False)

        self.environment_directory = QLineEdit(
            environment_directory(configured_python) if os.path.isfile(configured_python)
            and environment_directory(configured_python) else default_environment_directory())
        self.environment_directory.setToolTip(
            "Папка для нового окружения. Подойдёт новая или пустая папка, "
            "либо незавершённое окружение, созданное этим установщиком."
        )
        environment_row = QWidget(self)
        environment_layout = QHBoxLayout(environment_row)
        environment_layout.setContentsMargins(0, 0, 0, 0)
        environment_layout.addWidget(self.environment_directory)
        self.browse_directory_button = QPushButton("Папка…")
        self.browse_directory_button.clicked.connect(self._browse_directory)
        environment_layout.addWidget(self.browse_directory_button)
        form.addRow("Папка установки:", environment_row)
        layout.addLayout(form)

        self.python_help = QWidget(self)
        discovery_layout = QHBoxLayout(self.python_help)
        self.find_python_button = QPushButton("Найти Python")
        self.find_python_button.clicked.connect(self._discover_python)
        discovery_layout.addWidget(self.find_python_button)
        self.download_python_button = QPushButton("Скачать Python 3.11")
        self.download_python_button.clicked.connect(self._download_python)
        discovery_layout.addWidget(self.download_python_button)
        self.browse_python_button = QPushButton("Указать Python…")
        self.browse_python_button.clicked.connect(self._browse_python)
        discovery_layout.addWidget(self.browse_python_button)
        discovery_layout.addStretch()
        self.python_help.setVisible(False)
        layout.addWidget(self.python_help)

        self.stage_label = QLabel("Поиск установленного Python 3.11…")
        self.stage_label.setWordWrap(True)
        self.stage_label.setTextFormat(Qt.PlainText)
        layout.addWidget(self.stage_label)
        self.log = QPlainTextEdit()
        self.log.setReadOnly(True)
        self.log.document().setMaximumBlockCount(2000)
        self.log.setPlaceholderText("Здесь появятся этапы установки и сообщения pip.")
        self.log.setVisible(False)
        layout.addWidget(self.log)

        buttons = QHBoxLayout()
        journal = QPushButton("Журнал")
        journal.setCheckable(True)
        journal.toggled.connect(self.log.setVisible)
        buttons.addWidget(journal)
        buttons.addStretch()
        self.install_button = QPushButton("Установить")
        self.install_button.clicked.connect(self._start_install)
        buttons.addWidget(self.install_button)
        self.cancel_button = QPushButton("Закрыть")
        self.cancel_button.clicked.connect(self.reject)
        buttons.addWidget(self.cancel_button)
        layout.addLayout(buttons)
        self.environment_directory.textChanged.connect(self._update_location)
        self.environment_directory.editingFinished.connect(self._check_existing)
        self._update_location()
        # Let the dialog become visible before querying external interpreters.
        QTimer.singleShot(0, self._check_existing)

    @property
    def python_path(self):
        """The verified venv interpreter, set only on successful acceptance."""
        return self._python_path

    def _update_location(self, *unused):
        self._python_path = ""
        path = os.path.abspath(os.path.expanduser(self.environment_directory.text().strip()))
        try:
            marker = read_installation_marker(path)
        except (OSError, ValueError):
            marker = None
        reusable = bool(marker and marker.get("complete") and os.path.isfile(environment_python(path)))
        self.install_button.setText("Проверить и подключить" if reusable else "Установить")

    def _check_existing(self):
        if self._busy or self._closing:
            return
        if self._python_path:
            return
        directory = os.path.abspath(os.path.expanduser(self.environment_directory.text().strip()))
        python_path = environment_python(directory)
        if environment_directory(self._configured_python) == directory and os.path.isfile(self._configured_python):
            python_path = self._configured_python
        if not os.path.isfile(python_path):
            self._discover_python()
            return
        try:
            self._backend_directory = self._resolve_backend()
        except ValueError as error:
            self._fail(str(error))
            return
        self._venv_directory = directory
        self._bootstrap_python = python_path
        self._set_busy(True)
        self.stage_label.setText("Проверка установленной Urbanomy…")
        self._run(python_path, ["-c", VERIFY_SCRIPT], "status", backend=True)

    def _browse_python(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите исполняемый файл Python 3.11", self.bootstrap_python.currentText(),
            "Все файлы (*)",
        )
        if path:
            self.bootstrap_python.setEditText(path)

    def _browse_directory(self):
        path = QFileDialog.getExistingDirectory(
            self, "Выберите папку для окружения venv", self.environment_directory.text(),
        )
        if path:
            self.environment_directory.setText(path)
            self._check_existing()

    def _download_python(self):
        QDesktopServices.openUrl(QUrl(PYTHON_DOWNLOAD_URL))

    def _set_busy(self, busy):
        self._busy = bool(busy)
        for widget in (
            self.bootstrap_python, self.environment_directory, self.browse_python_button,
            self.browse_directory_button, self.find_python_button, self.download_python_button,
            self.install_button,
        ):
            widget.setEnabled(not busy)
        self.cancel_button.setText("Отмена" if busy else "Закрыть")

    def _append_log(self, message):
        if message:
            # Bound individual reads as well as the number of document lines.
            self.log.appendPlainText(str(message)[-32768:].rstrip())

    def _discover_python(self):
        if self._closing or self._busy:
            return
        current = self.bootstrap_python.currentText().strip() or self._configured_python
        self._candidates = list(executable_candidates(current))
        self._set_busy(True)
        self._try_next_candidate()

    def _try_next_candidate(self):
        if self._closing:
            return
        if not self._candidates:
            self._set_busy(False)
            self.stage_label.setText(
                "Python 3.11 не найден. Установите его по кнопке «Скачать Python 3.11», "
                "затем нажмите «Найти Python» или выберите исполняемый файл."
            )
            self.python_help.setVisible(True)
            return
        candidate = self._candidates.pop(0)
        self._bootstrap_python = candidate
        self.stage_label.setText("Проверка Python: {}".format(candidate))
        self._run(candidate, ["-I", "-c", PROBE_SCRIPT], "discover", probe=True)

    def _resolve_backend(self):
        for directory in (
            os.path.join(self._plugin_directory, "backend", "src"),
            os.path.abspath(os.path.join(self._plugin_directory, "..", "..", "src")),
        ):
            if os.path.isfile(os.path.join(directory, "urbanomy", "qgis_backend.py")):
                return directory
        raise ValueError(
            "В плагине отсутствует вычислительный модуль Urbanomy. "
            "Установите полную версию плагина из ZIP."
        )

    def _start_install(self):
        if self._busy or self._closing:
            return
        if self._python_path:
            self._closing = True
            super(InstallerDialog, self).accept()
            return
        self._python_path = ""
        self._reuse_environment = False
        try:
            raw_directory = self.environment_directory.text().strip()
            if not raw_directory:
                raise ValueError("Выберите папку для окружения venv.")
            directory = os.path.abspath(os.path.expanduser(raw_directory))
            marker = read_installation_marker(directory)
            self._reuse_environment = bool(
                marker and marker.get("complete") and os.path.isfile(environment_python(directory))
            )
            self._venv_directory = directory if self._reuse_environment else validate_install_directory(directory)
            self._backend_directory = self._resolve_backend()
            self._requirements_path = os.path.join(self._plugin_directory, "requirements.txt")
            if not self._reuse_environment and not os.path.isfile(self._requirements_path):
                raise ValueError(
                    "В плагине отсутствует requirements.txt. Установите полную версию из ZIP."
                )
            if self._reuse_environment:
                self._bootstrap_python = environment_python(self._venv_directory)
            else:
                entered_python = self.bootstrap_python.currentText().strip()
                if not entered_python:
                    raise ValueError("Сначала найдите или выберите Python 3.11.")
                self._bootstrap_python = os.path.abspath(os.path.expanduser(entered_python))
            if not os.path.isfile(self._bootstrap_python) or not os.access(self._bootstrap_python, os.X_OK):
                raise ValueError("Укажите существующий исполняемый файл Python 3.11.")
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "Проверьте установку", str(error))
            return
        self._set_busy(True)
        self.stage_label.setText("1/4. Проверка Python 3.11…")
        self._append_log("\nОкружение: {}".format(self._venv_directory))
        self._run(self._bootstrap_python, ["-I", "-c", PROBE_SCRIPT], "probe", probe=True)

    def _process_environment(self, backend=False):
        environment = QProcessEnvironment.systemEnvironment()
        for name in (
            "PYTHONHOME", "PYTHONPATH", "QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH",
            "QT_QPA_PLATFORM", "QT_QPA_FONTDIR",
            "PIP_TARGET", "PIP_PREFIX", "PIP_USER", "PIP_REQUIRE_VIRTUALENV",
            "VIRTUAL_ENV", "CONDA_PREFIX", "QGIS_PREFIX_PATH", "URBANOMY_API_KEY",
        ):
            environment.remove(name)
        environment.insert("PYTHONNOUSERSITE", "1")
        environment.insert("PYTHONUTF8", "1")
        environment.insert("PYTHONUNBUFFERED", "1")
        environment.insert("MPLBACKEND", "Agg")
        if backend:
            environment.insert("PYTHONPATH", self._backend_directory)
            user = os.getuid() if hasattr(os, "getuid") else os.getpid()
            environment.insert("MPLCONFIGDIR", os.path.join(
                tempfile.gettempdir(), "urbanomy-matplotlib-{}".format(user),
            ))
        return environment

    def _run(self, program, arguments, phase, probe=False, backend=False):
        self._phase = phase
        self._output = b""
        self._timed_out = False
        process = QProcess(self)
        self.process = process
        process.setProcessChannelMode(QProcess.MergedChannels)
        process.setProcessEnvironment(self._process_environment(backend=backend))
        process.setWorkingDirectory(self._plugin_directory)
        process.readyReadStandardOutput.connect(lambda: self._read_output(process))
        process.finished.connect(lambda code, status: self._finished(process, code, status))
        process.errorOccurred.connect(lambda error: self._process_error(process, error))
        self._append_log("Запуск: {} {}".format(program, " ".join(arguments[:4])))
        process.start(program, arguments)
        if probe and self.process is process:
            self._probe_timer.start(10000)

    def _read_output(self, process):
        if process is not self.process:
            return
        data = bytes(process.readAllStandardOutput())
        if data:
            self._output = (self._output + data)[-65536:]
            self._append_log(data.decode("utf-8", errors="replace"))

    def _dispose_process(self):
        self._probe_timer.stop()
        process = self.process
        self.process = None
        if process is not None:
            process.blockSignals(True)
            process.deleteLater()

    def _probe_timeout(self):
        if self.process is not None and self._phase in ("discover", "probe"):
            self._timed_out = True
            self._append_log("Проверка Python прервана: нет ответа в течение 10 секунд.")
            self.process.kill()

    def _process_error(self, process, error):
        if process is not self.process or error != QProcess.FailedToStart:
            return
        phase = self._phase
        message = "Не удалось запустить Python: {}".format(process.errorString())
        self._append_log(message)
        self._dispose_process()
        if phase == "discover":
            self._try_next_candidate()
        else:
            self._fail(message)

    def _probe_result(self, output):
        try:
            result = json.loads(output.decode("utf-8").strip())
            version = result["version"]
            if version[:2] != [3, 11]:
                raise ValueError(
                    "Нужен Python 3.11; выбран Python {}.{}.".format(version[0], version[1])
                )
            if result.get("bits") != 64:
                raise ValueError("Для вычислительных библиотек нужен Python 3.11 (64 бита).")
            return result
        except (UnicodeDecodeError, KeyError, IndexError, TypeError, json.JSONDecodeError):
            raise ValueError("Python не вернул корректную информацию о версии.")

    def _finished(self, process, exit_code, exit_status):
        if process is not self.process or self._closing:
            return
        self._read_output(process)
        phase, output, timed_out = self._phase, self._output, self._timed_out
        self._dispose_process()
        error = None
        if timed_out:
            error = "Python не ответил. Выберите другой исполняемый файл Python 3.11."
        elif exit_code != 0 or exit_status != QProcess.NormalExit:
            error = "Процесс завершился с ошибкой (код {}).".format(exit_code)
        if not error and phase in ("discover", "probe"):
            try:
                self._probe_result(output)
            except ValueError as probe_error:
                error = str(probe_error)
        if phase == "discover":
            if error:
                self._append_log(error)
                self._try_next_candidate()
            else:
                if self.bootstrap_python.findText(self._bootstrap_python) < 0:
                    self.bootstrap_python.addItem(self._bootstrap_python)
                self.bootstrap_python.setEditText(self._bootstrap_python)
                self.stage_label.setText("Python 3.11 найден. Можно установить окружение.")
                self.python_help.setVisible(False)
                self._set_busy(False)
            return
        if phase == "status":
            self._set_busy(False)
            if not error and b"URBANOMY_ENVIRONMENT_READY" in output:
                self._python_path = self._bootstrap_python
                self.stage_label.setText("Urbanomy уже установлена. Можно использовать это окружение.")
                self.install_button.setText("Использовать")
            else:
                self.stage_label.setText("В этой папке Urbanomy не готова к работе. Выберите новую папку для установки.")
                self.log.setVisible(True)
            return
        if error:
            self._fail(error)
            return
        try:
            if phase == "probe":
                if self._reuse_environment:
                    self._verify_environment()
                else:
                    # An ownership marker permits a safe retry after cancellation.
                    mark_installation(self._venv_directory, complete=False)
                    self.stage_label.setText("2/4. Создание отдельного окружения venv…")
                    self._run(self._bootstrap_python, ["-I", "-m", "venv", self._venv_directory], "venv")
            elif phase == "venv":
                self.stage_label.setText("3/4. Загрузка и установка библиотек — это может занять несколько минут…")
                self._run(environment_python(self._venv_directory), [
                    "-m", "pip", "--isolated", "install", "--disable-pip-version-check",
                    "--no-input", "--prefer-binary", "--no-user", "-r", self._requirements_path,
                ], "pip")
            elif phase == "pip":
                self._verify_environment()
            elif phase == "verify":
                if b"URBANOMY_ENVIRONMENT_READY" not in output:
                    raise ValueError("Вычислительный модуль не подтвердил готовность окружения.")
                if not self._reuse_environment:
                    mark_installation(self._venv_directory, complete=True)
                self._python_path = environment_python(self._venv_directory)
                self.stage_label.setText("Окружение установлено и проверено.")
                self._append_log("Готово. Python для расчётов: {}".format(self._python_path))
                self._set_busy(False)
                self._closing = True
                super(InstallerDialog, self).accept()
        except (OSError, ValueError) as stage_error:
            self._fail(str(stage_error))

    def _verify_environment(self):
        self.stage_label.setText("4/4. Проверка библиотек и вычислительного модуля Urbanomy…")
        self._run(environment_python(self._venv_directory), ["-c", VERIFY_SCRIPT], "verify", backend=True)

    def _fail(self, message):
        self._set_busy(False)
        self.log.setVisible(True)
        self.stage_label.setText("Установка не завершена. {}".format(message))
        self._append_log(message)
        detail = {
            "probe": "Выберите Python 3.11 (64 бита). Если его нет, скачайте и установите по кнопке в этом окне.",
            "venv": "Проверьте права на выбранную папку и наличие модуля venv у Python 3.11.",
            "pip": "Проверьте подключение к интернету и сообщения pip в журнале. После исправления нажмите «Установить» ещё раз; будет использована та же папка.",
            "verify": "Одна из библиотек не загрузилась. Подробности приведены в журнале. Для новой установки выберите другую пустую папку.",
        }.get(self._phase, "Проверьте пути и сообщения в журнале.")
        QMessageBox.warning(self, "Установка не завершена", "{}\n\n{}".format(message, detail))

    def _stop(self):
        self._closing = True
        self._probe_timer.stop()
        process = self.process
        self.process = None
        if process is not None:
            # Block before waiting: finished can be emitted during waitForFinished.
            process.blockSignals(True)
            if process.state() != QProcess.NotRunning:
                process.kill()
                process.waitForFinished(1000)
            process.deleteLater()

    def reject(self):
        self._stop()
        super(InstallerDialog, self).reject()

    def closeEvent(self, event):
        self._stop()
        super(InstallerDialog, self).closeEvent(event)
