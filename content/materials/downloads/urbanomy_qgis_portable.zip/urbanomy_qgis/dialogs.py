"""Qt dialogs for Urbanomy, compatible with QGIS 3.4 and Python 3.6."""

import csv
import json
import math
import os

from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import (
    QAbstractItemView,
    QCheckBox,
    QComboBox,
    QDialog,
    QDialogButtonBox,
    QFileDialog,
    QFormLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPlainTextEdit,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QVBoxLayout,
    QWidget,
)

from .install_support import environment_directory, environment_python
from .bridge import next_price_fields


SHARE_KEYS = (
    "residential", "business", "recreation", "industrial", "transport",
    "special", "agriculture",
)
CONSTRAINT_KEYS = ("footprint_area", "l", "mxi") + SHARE_KEYS
PARAMETER_LABELS = {
    "footprint_area": "Территория под зданиями, %",
    "l": "Средняя этажность",
    "mxi": "Жилая площадь внутри зданий, %",
    "residential": "Жилая застройка",
    "business": "Деловая застройка",
    "recreation": "Рекреационные территории",
    "industrial": "Промышленность",
    "transport": "Транспорт",
    "special": "Специальное назначение",
    "agriculture": "Сельское хозяйство",
}
SUMMARY_LABELS = {
    "count": "Кварталов",
    "objective": "Критерий",
    "land_value_total": "Стоимость земли всего слоя, руб.",
    "land_value_gain": "Изменение стоимости земли, руб.",
    "investor_npv": "NPV инвестора, руб.",
    "llm_score": "Оценка LLM",
    "llm_used": "LLM использована",
    "discount_rate": "Ставка дисконтирования",
    "repaired_geometries": "Исправлено геометрий для расчёта",
    "zero_area_count": "Кварталов с нулевой площадью",
    "pop_size": "Размер популяции (pop_size)",
    "n_gen": "Число поколений (n_gen)",
}
OBJECTIVE_LABELS = {
    "land_value": "Максимальная стоимость земли",
    "investor_npv": "Инвестиционная привлекательность (NPV инвестора)",
    "llm_score": "Оценка по функции LLM",
}
HIDDEN_SUMMARY_KEYS = {"metric_crs", "evaluations", "pareto_size", "repaired_geometries", "zero_area_count"}


def _float_text(value):
    return "{:.12g}".format(value)


def _read_float(text):
    """Accept either decimal separator, without silently accepting NaN/Inf."""
    value = float(text.strip().replace(",", "."))
    if not math.isfinite(value):
        raise ValueError("Значение должно быть конечным числом.")
    return value


def _display_value(value):
    if value is None:
        return "—"
    if isinstance(value, bool):
        return "Да" if value else "Нет"
    if isinstance(value, float):
        return "{:.10g}".format(value)
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False)
    return str(value)


def _summary_text(summary):
    if not isinstance(summary, dict):
        return _display_value(summary)
    lines = []
    for key, value in summary.items():
        if key in HIDDEN_SUMMARY_KEYS or (key == "llm_score" and value is None):
            continue
        if key == "objective":
            displayed = OBJECTIVE_LABELS.get(value, _display_value(value))
        elif key == "discount_rate" and isinstance(value, (int, float)):
            displayed = "{}%".format(_float_text(100 * value))
        else:
            displayed = _display_value(value)
        lines.append("{}: {}".format(SUMMARY_LABELS.get(key, key), displayed))
    return "\n".join(lines)


class EstimateDialog(QDialog):
    def __init__(self, parent, existing_fields):
        super(EstimateDialog, self).__init__(parent)
        self.setWindowTitle("Стоимость земли")
        self._existing_fields = list(existing_fields)
        self._values = None
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.mode = QComboBox()
        self.mode.addItem("Оба варианта", "both")
        self.mode.addItem("За сотку (100 м²)", "unit")
        self.mode.addItem("Стоимость целиком", "total")
        form.addRow("Рассчитать:", self.mode)
        total, unit = next_price_fields(self._existing_fields)
        self.total_name, self.unit_name = QLineEdit(total), QLineEdit(unit)
        form.addRow("Колонка полной стоимости:", self.total_name)
        form.addRow("Колонка стоимости за сотку:", self.unit_name)
        self.mode.currentIndexChanged.connect(self._mode_changed)
        layout.addLayout(form)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Рассчитать")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _mode_changed(self, *unused):
        self.total_name.setEnabled(self.mode.currentData() != "unit")
        self.unit_name.setEnabled(self.mode.currentData() != "total")

    def accept(self):
        mode = self.mode.currentData()
        try:
            total, unit = next_price_fields(
                self._existing_fields,
                self.total_name.text().strip() if mode != "unit" else None,
                self.unit_name.text().strip() if mode != "total" else None,
            )
        except ValueError as error:
            QMessageBox.warning(self, "Проверьте названия", str(error))
            return
        self._values = {"price_fields": {"total": total, "unit": unit}}
        super(EstimateDialog, self).accept()

    def values(self):
        return self._values


INVESTMENT_LABELS = {
    "cost_build": "Строительство, руб./м²",
    "cost_demolition": "Снос, руб./м²",
    "price_sale": "Продажа, руб./м²",
    "rent_annual": "Аренда, руб./м² в год",
    "opex_rate": "Эксплуатация, руб./м² в год",
    "construction_years": "Строительство, лет",
    "sale_years": "Продажи, лет",
    "rent_years": "Аренда, лет",
}


class InvestmentSettingsDialog(QDialog):
    def __init__(self, parent, parameters):
        super(InvestmentSettingsDialog, self).__init__(parent)
        self.setWindowTitle("Параметры инвестиционного расчёта")
        self.resize(560, 420)
        self._values = json.loads(json.dumps(parameters))
        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.rate = QLineEdit(_float_text(parameters["discount_rate"] * 100))
        form.addRow("Ставка дисконтирования, %:", self.rate)
        self.land_use = QComboBox()
        for key in parameters["benchmarks"]:
            self.land_use.addItem(PARAMETER_LABELS[key], key)
        form.addRow("Тип застройки:", self.land_use)
        layout.addLayout(form)
        self.table = QTableWidget(0, 2)
        self.table.setHorizontalHeaderLabels(["Параметр", "Значение"])
        self.table.verticalHeader().setVisible(False)
        self.table.horizontalHeader().setStretchLastSection(True)
        layout.addWidget(self.table)
        self._profile_key = None
        self._load_profile()
        self.land_use.currentIndexChanged.connect(self._change_profile)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Применить")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _load_profile(self):
        self._profile_key = self.land_use.currentData()
        profile = self._values["benchmarks"][self._profile_key]
        self.table.setRowCount(len(profile))
        for row, (key, value) in enumerate(profile.items()):
            label = QTableWidgetItem(INVESTMENT_LABELS[key])
            label.setFlags(label.flags() & ~Qt.ItemIsEditable)
            self.table.setItem(row, 0, label)
            self.table.setItem(row, 1, QTableWidgetItem(_float_text(value)))
        self.table.resizeColumnsToContents()

    def _store_profile(self):
        profile = self._values["benchmarks"][self._profile_key]
        updated = {}
        for row, key in enumerate(profile):
            value = _read_float(self.table.item(row, 1).text())
            if value < 0 or value > 1e15:
                raise ValueError("{}: укажите неотрицательное значение до 10¹⁵.".format(INVESTMENT_LABELS[key]))
            if key.endswith("_years"):
                if not value.is_integer() or not 1 <= value <= 100:
                    raise ValueError("Срок должен быть целым числом от 1 до 100 лет.")
                value = int(value)
            updated[key] = value
        self._values["benchmarks"][self._profile_key] = updated

    def _change_profile(self, *unused):
        try:
            self._store_profile()
        except ValueError as error:
            QMessageBox.warning(self, "Проверьте параметры", str(error))
            self.land_use.blockSignals(True)
            self.land_use.setCurrentIndex(self.land_use.findData(self._profile_key))
            self.land_use.blockSignals(False)
            return
        self._load_profile()

    def accept(self):
        try:
            self._store_profile()
            rate = _read_float(self.rate.text()) / 100
            if not 0 <= rate <= 10:
                raise ValueError("Ставка дисконтирования должна быть от 0 до 1000%.")
        except ValueError as error:
            QMessageBox.warning(self, "Проверьте параметры", str(error))
            return
        self._values["discount_rate"] = rate
        super(InvestmentSettingsDialog, self).accept()

    def values(self):
        return self._values


class InvestmentDialog(QDialog):
    def __init__(self, parent, parameters=None):
        super(InvestmentDialog, self).__init__(parent)
        self.setWindowTitle("Инвестиционная привлекательность")
        with open(os.path.join(os.path.dirname(__file__), "investment_defaults.json"), encoding="utf-8") as handle:
            self._defaults = json.load(handle)
        self._values = parameters or self._defaults
        layout = QVBoxLayout(self)
        self.summary = QLabel()
        layout.addWidget(self.summary)
        change = QPushButton("Изменить параметры…")
        change.clicked.connect(self._change_parameters)
        layout.addWidget(change)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Рассчитать")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._update_summary()

    def _update_summary(self):
        self.summary.setText("Ставка дисконтирования: {}%\nФинансовые нормативы: {}".format(
            _float_text(self._values["discount_rate"] * 100),
            "Urbanomy" if self._values == self._defaults else "изменены"))

    def _change_parameters(self):
        dialog = InvestmentSettingsDialog(self, self._values)
        if dialog.exec_() == QDialog.Accepted:
            self._values = dialog.values()
            self._update_summary()
        dialog.deleteLater()

    def values(self):
        return {"investment_parameters": self._values}


class SettingsDialog(QDialog):
    """Collect paths and optional, session-only LLM credentials."""

    def __init__(self, parent, settings_dict, defaults_dict, install_callback=None,
                 check_llm_callback=None):
        super(SettingsDialog, self).__init__(parent)
        self.setWindowTitle("Настройки Urbanomy")
        self.resize(620, 240)
        self._values = None
        self._install_callback = install_callback
        self._check_llm_callback = check_llm_callback
        self._syncing_environment = False
        self.install_button = None
        settings = dict(defaults_dict or {})
        settings.update(settings_dict or {})

        layout = QVBoxLayout(self)
        form = QFormLayout()
        self.model_path = QLineEdit(str(settings.get("model_path") or ""))
        self.model_path.setPlaceholderText("Путь к модели CatBoost (.cbm)")
        self.model_path.setToolTip("Обученная модель CatBoost для расчёта цены земли.")
        form.addRow("Модель CatBoost:", self._path_row(self.model_path, self._browse_model))
        layout.addLayout(form)
        environment = QWidget(self)
        environment_form = QFormLayout(environment)

        python_path = str(settings.get("python_path") or "")
        venv_path = str(settings.get("venv_path") or environment_directory(python_path))
        self.venv_path = QLineEdit(venv_path)
        self.venv_path.setPlaceholderText("Например: ~/Library/Application Support/Urbanomy/venv")
        self.venv_path.setToolTip(
            "Папка существующего вычислительного окружения. Python в ней выбирается автоматически. "
            "Смена папки не переустанавливает библиотеки."
        )
        environment_form.addRow("Папка окружения:", self._path_row(self.venv_path, self._browse_venv))
        self.python_path = QLineEdit(python_path or (environment_python(venv_path) if venv_path else ""))
        self.python_path.setPlaceholderText("Например: /путь/к/venv/bin/python")
        self.python_path.setToolTip(
            "Исполняемый файл Python 3.10 или новее в отдельном окружении "
            "с установленными Urbanomy и CatBoost."
        )
        environment_form.addRow("Python:", self._path_row(self.python_path, self._browse_python))
        if install_callback is not None:
            self.install_button = QPushButton("Установить библиотеки в отдельное окружение…")
            self.install_button.clicked.connect(self._install_environment)
            environment_form.addRow("", self.install_button)
        self.venv_path.textChanged.connect(self._venv_changed)
        self.python_path.textChanged.connect(self._python_changed)
        self._update_install_button()

        llm = QWidget(self)
        form = QFormLayout(llm)

        self.api_key = QLineEdit(str(settings.get("api_key") or ""))
        self.api_key.setEchoMode(QLineEdit.Password)
        self.api_key.setPlaceholderText("Необязательно — для использования LLM")
        self.api_key.setToolTip(
            "Вставьте только значение ключа: без FP2MP_API_KEY=, кавычек и Bearer. "
            "Ключ хранится только в памяти до завершения сеанса плагина."
        )
        form.addRow("API-ключ LLM:", self.api_key)

        self.llm_base_url = QLineEdit(
            str(settings.get("llm_base_url") or "https://routerai.ru/api/v1")
        )
        self.llm_base_url.setToolTip(
            "Базовый URL провайдера, который выпустил ключ. "
            "RouterAI: https://routerai.ru/api/v1."
        )
        form.addRow("URL API:", self.llm_base_url)
        routerai_button = QPushButton("Использовать RouterAI")
        routerai_button.setToolTip("Подставить URL RouterAI в форму. Для сохранения нажмите «Сохранить».")
        routerai_button.clicked.connect(self._use_routerai)
        form.addRow("", routerai_button)
        self.llm_model = QLineEdit(
            str(settings.get("llm_model") or "deepseek/deepseek-v4-flash")
        )
        self.llm_model.setToolTip("Идентификатор модели у выбранного провайдера LLM.")
        form.addRow("Модель LLM:", self.llm_model)
        if check_llm_callback is not None:
            self.check_llm_button = QPushButton("Проверить LLM — один запрос")
            self.check_llm_button.setToolTip(
                "Проверить введённые ключ, URL и модель одним коротким запросом. "
                "Сохранять настройки перед проверкой не нужно."
            )
            self.check_llm_button.clicked.connect(self._check_llm)
            form.addRow("", self.check_llm_button)
        llm_toggle = QCheckBox("Настройки LLM")
        llm_toggle.setChecked(bool(settings.get("api_key")))
        llm.setVisible(llm_toggle.isChecked())
        llm_toggle.toggled.connect(llm.setVisible)
        layout.addWidget(llm_toggle)
        layout.addWidget(llm)
        advanced_toggle = QCheckBox("Дополнительно: вычислительное окружение")
        environment.setVisible(False)
        advanced_toggle.toggled.connect(environment.setVisible)
        layout.addWidget(advanced_toggle)
        layout.addWidget(environment)

        note = QLabel("Установка — в меню Urbanomy → Установка. API-ключ хранится только до закрытия плагина.")
        note.setWordWrap(True)
        layout.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Сохранить")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _path_row(self, line_edit, callback):
        widget = QWidget(self)
        row = QHBoxLayout(widget)
        row.setContentsMargins(0, 0, 0, 0)
        row.addWidget(line_edit)
        button = QPushButton("Выбрать…")
        button.clicked.connect(callback)
        row.addWidget(button)
        return widget

    def _browse_model(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите модель CatBoost", self.model_path.text(),
            "Модель CatBoost (*.cbm);;Все файлы (*)",
        )
        if path:
            self.model_path.setText(path)

    def _browse_python(self):
        path, _ = QFileDialog.getOpenFileName(
            self, "Выберите Python отдельного окружения", self.python_path.text(),
            "Все файлы (*)",
        )
        if path:
            self.python_path.setText(path)

    def _browse_venv(self):
        path = QFileDialog.getExistingDirectory(
            self, "Выберите папку вычислительного окружения venv", self.venv_path.text(),
        )
        if path:
            self.venv_path.setText(path)

    def _venv_changed(self, text=None):
        if self._syncing_environment:
            return
        self._syncing_environment = True
        try:
            directory = self.venv_path.text().strip()
            self.python_path.setText(environment_python(directory) if directory else "")
        finally:
            self._syncing_environment = False
        self._update_install_button()

    def _python_changed(self, text=None):
        if self._syncing_environment:
            return
        self._syncing_environment = True
        try:
            self.venv_path.setText(environment_directory(self.python_path.text().strip()))
        finally:
            self._syncing_environment = False
        self._update_install_button()

    def _update_install_button(self):
        if self.install_button is not None:
            path = os.path.abspath(os.path.expanduser(self.python_path.text().strip()))
            self.install_button.setVisible(not (os.path.isfile(path) and os.access(path, os.X_OK)))

    def _install_environment(self):
        if self._install_callback is not None:
            path = self._install_callback()
            if path:
                self.python_path.setText(path)
                self._python_changed()

    def _check_llm(self):
        if self._check_llm_callback is not None:
            self._check_llm_callback({
                "python_path": self.python_path.text().strip(),
                "api_key": self.api_key.text().strip(),
                "llm_base_url": self.llm_base_url.text().strip(),
                "llm_model": self.llm_model.text().strip(),
            }, self)

    def _use_routerai(self):
        self.llm_base_url.setText("https://routerai.ru/api/v1")

    def accept(self):
        model_path = os.path.abspath(os.path.expanduser(self.model_path.text().strip()))
        python_path = os.path.abspath(os.path.expanduser(self.python_path.text().strip()))
        if not self.model_path.text().strip() or not os.path.isfile(model_path):
            QMessageBox.warning(self, "Проверьте модель", "Укажите существующий файл модели CatBoost.")
            self.model_path.setFocus()
            return
        if not model_path.lower().endswith(".cbm"):
            QMessageBox.warning(self, "Проверьте модель", "Выберите модель CatBoost с расширением .cbm.")
            self.model_path.setFocus()
            return
        if (not self.python_path.text().strip() or not os.path.isfile(python_path)
                or not os.access(python_path, os.X_OK)):
            QMessageBox.warning(
                self, "Проверьте Python",
                "Укажите исполняемый файл Python 3.10+ из окружения с Urbanomy.",
            )
            self.python_path.setFocus()
            return
        api_key = self.api_key.text().strip()
        base_url = self.llm_base_url.text().strip().rstrip("/")
        model = self.llm_model.text().strip()
        if api_key and (not base_url.startswith(("https://", "http://")) or not model):
            QMessageBox.warning(
                self, "Проверьте настройки LLM",
                "Для использования ключа укажите URL API (http:// или https://) и модель LLM.",
            )
            return
        self._values = {
            "model_path": model_path,
            "python_path": python_path,
            "venv_path": (os.path.abspath(os.path.expanduser(self.venv_path.text().strip()))
                          if self.venv_path.text().strip() else ""),
            "api_key": api_key,
            "llm_base_url": base_url,
            "llm_model": model,
        }
        super(SettingsDialog, self).accept()

    def values(self):
        return dict(self._values or {})


class ConstraintsDialog(QDialog):
    """Show student-facing bounds and convert display units for the worker."""

    def __init__(self, parent, site_area):
        super(ConstraintsDialog, self).__init__(parent)
        self.site_area = float(site_area)
        if not math.isfinite(self.site_area) or self.site_area <= 0:
            raise ValueError("Площадь выбранной территории должна быть положительной.")
        self._values = None
        self.setWindowTitle("Параметры будущего квартала")
        self.resize(720, 620)
        layout = QVBoxLayout(self)
        info = QLabel(
            "Площадь квартала: {} га.\n"
            "Задайте, какие варианты застройки можно рассматривать. "
            "Программа найдёт решение внутри указанных границ."
            .format("{:,.2f}".format(self.site_area / 10000).replace(",", " ").replace(".", ","))
        )
        info.setWordWrap(True)
        layout.addWidget(info)
        self.building_table = QTableWidget(3, 3)
        self.land_use_table = QTableWidget(len(SHARE_KEYS), 3)
        tips = {
            "footprint_area": "Площадь, которую здания занимают на земле. Не более 80% территории.",
            "l": "Среднее число этажей. Можно указать дробное значение; минимум — 1 этаж.",
            "mxi": "Какая часть общей площади зданий приходится на жильё. "
                   "Например, 60% означает 60 м² жилья на каждые 100 м² площади зданий. "
                   "mxi = living_area / build_floor_area.",
        }
        for table, keys, title, headers in (
            (self.building_table, CONSTRAINT_KEYS[:3], "Застройка",
             ["Параметр", "От", "До"]),
            (self.land_use_table, SHARE_KEYS, "Распределение территории · доли от 0 до 1",
             ["Использование территории", "Не менее", "Не более"]),
        ):
            layout.addWidget(QLabel(title))
            table.setHorizontalHeaderLabels(headers)
            table.verticalHeader().setVisible(False)
            table.setAlternatingRowColors(True)
            table.setSelectionBehavior(QAbstractItemView.SelectItems)
            for row, key in enumerate(keys):
                lower, upper = 0.0, 1.0
                if key == "footprint_area":
                    upper = 10.0
                elif key == "l":
                    lower, upper = 1.0, 10.0
                elif key == "mxi":
                    lower, upper = 10.0, 100.0
                name = QTableWidgetItem(PARAMETER_LABELS[key])
                name.setFlags(name.flags() & ~Qt.ItemIsEditable)
                name.setToolTip(tips.get(key, "Доля территории для этого использования. "
                                        "0,3 = 30%; 0–0 исключает использование.") + "\nПоле: " + key)
                table.setItem(row, 0, name)
                table.setItem(row, 1, QTableWidgetItem(_float_text(lower)))
                table.setItem(row, 2, QTableWidgetItem(_float_text(upper)))
            table.setColumnWidth(1, 110)
            table.setColumnWidth(2, 110)
            table.horizontalHeader().setSectionResizeMode(0, QHeaderView.Stretch)
            table.resizeRowsToContents()
            table.setFixedHeight(table.horizontalHeader().sizeHint().height()
                                 + sum(table.rowHeight(row) for row in range(table.rowCount()))
                                 + 2 * table.frameWidth())
            layout.addWidget(table)
            if table is self.building_table:
                self.area_preview = QLabel()
                layout.addWidget(self.area_preview)
        note = QLabel(
            "В итоговом варианте доли территории составят 1. Например, 0,3 = 30%. "
            "Жилая территория и жилая площадь внутри зданий — разные параметры.\n"
            "Одинаковые границы фиксируют значение: 5–5 — ровно 5 этажей; "
            "0–0 в распределении исключает использование."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        self.status = QLabel()
        self.status.setWordWrap(True)
        layout.addWidget(self.status)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        self.next_button = buttons.button(QDialogButtonBox.Ok)
        self.next_button.setText("К настройке поиска →")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self.building_table.cellChanged.connect(self._update_preview)
        self.land_use_table.cellChanged.connect(self._update_preview)
        self._update_preview()

    def _read_constraints(self):
        values = {}
        for table, keys in ((self.building_table, CONSTRAINT_KEYS[:3]), (self.land_use_table, SHARE_KEYS)):
            for row, key in enumerate(keys):
                label = PARAMETER_LABELS[key]
                try:
                    lower = _read_float(table.item(row, 1).text())
                    upper = _read_float(table.item(row, 2).text())
                except (ValueError, AttributeError):
                    raise ValueError("{}: заполните обе границы числами. Можно использовать точку или запятую.".format(label))
                if lower > upper:
                    raise ValueError("{}: нижняя граница не может быть больше верхней.".format(label))
                if key == "footprint_area":
                    if lower < 0 or upper > 80:
                        raise ValueError("Территория под зданиями: допустимо от 0 до 80% площади квартала.")
                    lower, upper = lower / 100 * self.site_area, upper / 100 * self.site_area
                elif key == "l":
                    if lower < 1:
                        raise ValueError("Средняя этажность должна быть не менее 1.")
                elif key == "mxi":
                    if lower < 0 or upper > 100:
                        raise ValueError("Жилая площадь внутри зданий: допустимо от 0 до 100%.")
                    lower, upper = lower / 100, upper / 100
                elif lower < 0 or upper > 1:
                    raise ValueError("{}: доля должна быть от 0 до 1.".format(label))
                values[key] = {"type": "float", "min": lower, "max": upper}
        min_sum = sum(values[key]["min"] for key in SHARE_KEYS)
        max_sum = sum(values[key]["max"] for key in SHARE_KEYS)
        if min_sum > 1 + 1e-12:
            raise ValueError("Минимальные доли составляют {}. Уменьшите их суммарно на {}: "
                             "вся территория — это 1.".format(_float_text(min_sum), _float_text(min_sum - 1)))
        if max_sum < 1 - 1e-12:
            raise ValueError("Максимальные доли позволяют распределить только {} территории. "
                             "Увеличьте их суммарно на {}, чтобы получить 1."
                             .format(_float_text(max_sum), _float_text(1 - max_sum)))
        return values

    def _update_preview(self, *unused):
        try:
            values = self._read_constraints()
        except ValueError as error:
            self.area_preview.setText("")
            self.status.setText(str(error))
            self.next_button.setEnabled(False)
            return
        footprint = values["footprint_area"]
        scale, unit = (10000, "га") if footprint["max"] >= 10000 else (1, "м²")
        self.area_preview.setText("Под зданиями: от {} до {} {}.".format(
            "{:,.2f}".format(footprint["min"] / scale).replace(",", " ").replace(".", ","),
            "{:,.2f}".format(footprint["max"] / scale).replace(",", " ").replace(".", ","), unit))
        self.status.setText("Доли совместимы: можно получить сумму 1.")
        self.next_button.setEnabled(True)

    def accept(self):
        try:
            values = self._read_constraints()
        except ValueError as error:
            QMessageBox.warning(self, "Проверьте параметры квартала", str(error))
            return
        self._values = values
        super(ConstraintsDialog, self).accept()

    def values(self):
        return dict((key, dict(value)) for key, value in (self._values or {}).items())


class OptimizerDialog(QDialog):
    """Choose optimizer settings and an optional language-model objective."""

    def __init__(self, parent, has_api_key):
        super(OptimizerDialog, self).__init__(parent)
        self._values = None
        self._has_api_key = bool(has_api_key)
        self.setWindowTitle("Параметры оптимизатора")
        self.resize(690, 530)
        layout = QVBoxLayout(self)
        description = QLabel(
            "Оптимизатор ищет параметры для выбранного квартала. "
            "Лучший вариант будет применён к его атрибутам. "
            "Стоимость означает суммарную стоимость земли всего слоя; "
            "инвестиционная привлекательность — NPV инвестора (чистая приведённая стоимость)."
        )
        description.setWordWrap(True)
        layout.addWidget(description)
        form = QFormLayout()
        self.pop_size = QSpinBox()
        self.pop_size.setRange(4, 10000)
        self.pop_size.setValue(20)
        self.pop_size.setToolTip("Количество вариантов в одном поколении (pop_size).")
        form.addRow("Размер популяции (pop_size):", self.pop_size)
        self.n_gen = QSpinBox()
        self.n_gen.setRange(1, 10000)
        self.n_gen.setValue(20)
        self.n_gen.setToolTip("Количество поколений оптимизации (n_gen).")
        form.addRow("Число поколений (n_gen):", self.n_gen)
        self.seed = QSpinBox()
        self.seed.setRange(0, 2147483647)
        self.seed.setValue(42)
        self.seed.setToolTip("Начальное число для воспроизводимости случайного поиска.")
        form.addRow("Начальное число (seed):", self.seed)
        self.objective = QComboBox()
        self.objective.addItem("Максимальная стоимость земли", "land_value")
        self.objective.addItem("Инвестиционная привлекательность (NPV инвестора)", "investor_npv")
        self.objective.addItem("Оценка по функции LLM", "llm_score")
        form.addRow("Выбрать лучший вариант по:", self.objective)
        layout.addLayout(form)
        self.show_scenario_impact = QCheckBox("Показать изменение стоимости на карте после оптимизации")
        self.show_scenario_impact.setToolTip(
            "Создать отдельный слой с изменением полной стоимости всех кварталов в рублях и процентах. "
            "Сравнение с состоянием перед текущим запуском."
        )
        layout.addWidget(self.show_scenario_impact)
        self.use_llm = QCheckBox("Использовать LLM")
        self.use_llm.setEnabled(self._has_api_key)
        self.use_llm.setChecked(False)
        self.use_llm.toggled.connect(self._toggle_llm)
        layout.addWidget(self.use_llm)
        self.prompt = QPlainTextEdit()
        self.prompt.setPlaceholderText(
            "Опишите желаемые изменения территории и критерии оценки варианта…"
        )
        self.prompt.setToolTip("Промпт используется только при включённой LLM.")
        layout.addWidget(self.prompt)
        note = QLabel(
            "LLM включается по желанию. При включении введите промпт; "
            "запросы отправляются настроенному провайдеру API."
            if self._has_api_key else
            "API-ключ не указан: промпт и оценка LLM недоступны. "
            "Оптимизация по стоимости и NPV инвестора доступна."
        )
        note.setWordWrap(True)
        layout.addWidget(note)
        buttons = QDialogButtonBox(QDialogButtonBox.Ok | QDialogButtonBox.Cancel)
        buttons.button(QDialogButtonBox.Ok).setText("Начать оптимизацию")
        buttons.button(QDialogButtonBox.Cancel).setText("Отмена")
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._toggle_llm(False)

    def _toggle_llm(self, enabled):
        enabled = bool(enabled) and self._has_api_key
        self.prompt.setEnabled(enabled)
        self.prompt.setVisible(enabled)
        self.objective.model().item(2).setEnabled(enabled)
        if not enabled and self.objective.currentData() == "llm_score":
            self.objective.setCurrentIndex(0)

    def accept(self):
        use_llm = self._has_api_key and self.use_llm.isChecked()
        prompt = self.prompt.toPlainText().strip() if use_llm else ""
        if use_llm and not prompt:
            QMessageBox.warning(self, "Введите промпт", "Опишите задачу для LLM или отключите LLM.")
            self.prompt.setFocus()
            return
        objective = self.objective.currentData()
        if objective == "llm_score" and not use_llm:
            QMessageBox.warning(self, "Проверьте критерий", "Для критерия LLM включите LLM и укажите промпт.")
            return
        self._values = {
            "pop_size": self.pop_size.value(),
            "n_gen": self.n_gen.value(),
            "seed": self.seed.value(),
            "objective": objective,
            "prompt": prompt,
            "use_llm": bool(use_llm),
            "show_scenario_impact": self.show_scenario_impact.isChecked(),
        }
        super(OptimizerDialog, self).accept()

    def values(self):
        return dict(self._values or {})


class ResultsDialog(QDialog):
    """Display per-feature attributes from a worker response and export CSV."""

    def __init__(self, parent, title, response):
        super(ResultsDialog, self).__init__(parent)
        self.setWindowTitle(title)
        self.resize(1000, 580)
        self._rows = list(response.get("rows") or [])
        self._columns = []
        self._labels = []
        for column in response.get("columns") or []:
            if isinstance(column, dict):
                key = column.get("name") or column.get("key")
                if key is None:
                    continue
                label = column.get("label") or key
                if column.get("unit"):
                    label = "{} ({})".format(label, column["unit"])
            else:
                key, label = str(column), str(column)
            if key not in self._columns:
                self._columns.append(key)
                self._labels.append(str(label))
        if not self._columns:
            for row in self._rows:
                for key in row.get("attributes") or {}:
                    if key not in self._columns:
                        self._columns.append(key)
                        self._labels.append(str(key))

        layout = QVBoxLayout(self)
        summary = response.get("summary")
        if summary is not None:
            label = QLabel(_summary_text(summary))
            label.setWordWrap(True)
            label.setTextFormat(Qt.PlainText)
            label.setTextInteractionFlags(Qt.TextSelectableByMouse)
            layout.addWidget(label)
        if not self._rows:
            label = QLabel("Нет результатов для отображения.")
            layout.addWidget(label)
        self.table = QTableWidget(len(self._rows), len(self._columns) + 1)
        self.table.setHorizontalHeaderLabels(["FID"] + self._labels)
        self.table.verticalHeader().setVisible(False)
        self.table.setEditTriggers(QAbstractItemView.NoEditTriggers)
        self.table.setSelectionBehavior(QAbstractItemView.SelectRows)
        self.table.setAlternatingRowColors(True)
        for row_index, row in enumerate(self._rows):
            attributes = row.get("attributes") or {}
            values = [row.get("fid")] + [attributes.get(key) for key in self._columns]
            for column_index, value in enumerate(values):
                item = QTableWidgetItem(_display_value(value))
                item.setFlags(item.flags() & ~Qt.ItemIsEditable)
                item.setToolTip(_display_value(value))
                self.table.setItem(row_index, column_index, item)
        self.table.resizeColumnsToContents()
        layout.addWidget(self.table)
        buttons = QDialogButtonBox(QDialogButtonBox.Close)
        buttons.button(QDialogButtonBox.Close).setText("Закрыть")
        export = QPushButton("Экспорт CSV…")
        export.setEnabled(bool(self._rows))
        export.clicked.connect(self._export_csv)
        buttons.addButton(export, QDialogButtonBox.ActionRole)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)

    def _export_csv(self):
        path, _ = QFileDialog.getSaveFileName(
            self, "Экспортировать результаты", "urbanomy_results.csv", "CSV (*.csv)",
        )
        if not path:
            return
        if not path.lower().endswith(".csv"):
            path += ".csv"
        try:
            with open(path, "w", encoding="utf-8-sig", newline="") as output:
                writer = csv.writer(output, delimiter=";")
                writer.writerow(["FID"] + self._labels)
                for row in self._rows:
                    attributes = row.get("attributes") or {}
                    values = [row.get("fid")] + [attributes.get(key) for key in self._columns]
                    writer.writerow([
                        json.dumps(value, ensure_ascii=False)
                        if isinstance(value, (dict, list, tuple)) else value
                        for value in values
                    ])
        except (OSError, ValueError) as error:
            QMessageBox.warning(self, "Ошибка экспорта", "Не удалось сохранить CSV:\n{}".format(error))
            return
        QMessageBox.information(self, "Экспорт завершён", "Результаты сохранены:\n{}".format(path))
