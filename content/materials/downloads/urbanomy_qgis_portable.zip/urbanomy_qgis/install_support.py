"""Filesystem-only installer helpers, compatible with QGIS's Python 3.6.

Version probes and package installation run through QProcess in the dialog so
these helpers never launch a process or block the QGIS interface.
"""

import json
import os
import shutil
import sys
import tempfile


INSTALLATION_MARKER = ".urbanomy-installer.json"
_INSTALLER = "urbanomy-qgis"
_MARKER_VERSION = 1


def default_environment_directory():
    """Keep the shared plugin and its scientific environment in separate folders."""
    home = os.path.expanduser("~")
    if sys.platform == "darwin":
        base = os.path.join(home, "Library", "Application Support")
    elif os.name == "nt":
        base = os.environ.get("APPDATA") or os.path.join(home, "AppData", "Roaming")
    else:
        base = os.environ.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    return os.path.abspath(os.path.join(base, "Urbanomy", "venv"))


def executable_candidates(configured_path=""):
    """Return existing Python executables to probe, preserving their symlinks."""
    candidates = [configured_path]
    candidates.extend(shutil.which(name) for name in ("python3.11", "python3", "python"))
    candidates.extend([
        "/Library/Frameworks/Python.framework/Versions/3.11/bin/python3.11",
        "/opt/homebrew/bin/python3.11",
        "/usr/local/bin/python3.11",
        "/usr/bin/python3.11",
    ])
    if sys.version_info[:2] == (3, 11):
        candidates.append(sys.executable)
    local_app_data = os.environ.get("LOCALAPPDATA")
    if local_app_data:
        candidates.append(os.path.join(local_app_data, "Programs", "Python", "Python311", "python.exe"))

    result = []
    for candidate in candidates:
        if not candidate:
            continue
        path = os.path.abspath(os.path.expanduser(candidate))
        if path not in result and os.path.isfile(path) and os.access(path, os.X_OK):
            result.append(path)
    return result


def environment_python(venv_dir):
    """Do not resolve the executable: venv's symlink keeps its environment."""
    directory = os.path.abspath(os.path.expanduser(str(venv_dir)))
    if os.name == "nt":
        return os.path.join(directory, "Scripts", "python.exe")
    return os.path.join(directory, "bin", "python")


def environment_directory(python_path):
    """Infer an environment folder from its executable without resolving links."""
    if not str(python_path or "").strip():
        return ""
    path = os.path.abspath(os.path.expanduser(str(python_path)))
    parent = os.path.dirname(path)
    executable = os.path.basename(path).lower()
    folder = os.path.basename(parent).lower()
    if ((folder == "bin" and executable.startswith("python"))
            or (folder == "scripts" and executable == "python.exe")):
        return os.path.dirname(parent)
    return ""


def _directory_path(directory):
    if not str(directory).strip():
        raise ValueError("Укажите отдельную папку для вычислительного окружения.")
    return os.path.realpath(os.path.abspath(os.path.expanduser(str(directory))))


def _within(path, parent):
    try:
        return os.path.commonpath((path, parent)) == parent
    except ValueError:
        return False


def read_installation_marker(directory):
    """Read only our marker, bound to this directory; malformed means unowned."""
    path = _directory_path(directory)
    marker = os.path.join(path, INSTALLATION_MARKER)
    if os.path.islink(marker):
        return None
    try:
        with open(marker, "r", encoding="utf-8") as stream:
            state = json.load(stream)
    except (OSError, ValueError):
        return None
    if (not isinstance(state, dict)
            or state.get("installer") != _INSTALLER
            or state.get("version") != _MARKER_VERSION
            or state.get("directory") != path
            or type(state.get("complete")) is not bool):
        return None
    return state


def validate_install_directory(directory):
    """Allow a fresh folder or retry of our unfinished installation only."""
    supplied = os.path.abspath(os.path.expanduser(str(directory)))
    path = _directory_path(directory)
    if os.path.islink(supplied):
        raise ValueError("Выберите отдельную папку, а не символическую ссылку.")

    home = os.path.realpath(os.path.expanduser("~"))
    plugin = os.path.realpath(os.path.dirname(__file__))
    if path == os.path.dirname(path) or path == home or _within(path, plugin):
        raise ValueError("Выберите новую папку для окружения, вне папки плагина.")

    # These locations contain applications or operating-system components.
    system_directories = ["/System", "/Library", "/Applications", "/usr", "/bin", "/sbin", "/etc"]
    if os.name == "nt":
        system_directories = [os.environ.get(name) for name in ("WINDIR", "ProgramFiles", "ProgramFiles(x86)")]
    for protected in system_directories:
        if protected and _within(path, os.path.realpath(protected)):
            raise ValueError("Окружение нельзя установить в системную папку.")
    parts = path.replace("\\", "/").lower().split("/")
    if "qgis" in parts or "qgis3" in parts:
        for index in range(len(parts) - 1):
            if parts[index:index + 2] == ["python", "plugins"]:
                raise ValueError("Установите окружение вне папки модулей QGIS.")

    if os.path.exists(path):
        if not os.path.isdir(path):
            raise ValueError("По этому пути уже существует файл.")
        if os.listdir(path):
            state = read_installation_marker(path)
            if state is None or state["complete"]:
                raise ValueError("Папка уже занята. Выберите новую или пустую папку; существующее окружение не будет изменено.")
    return path


def mark_installation(directory, complete=False):
    """Create a recoverable target and atomically record its installation state."""
    if type(complete) is not bool:
        raise ValueError("Некорректный статус установки.")
    path = validate_install_directory(directory)
    os.makedirs(path, exist_ok=True)
    # Check again after creation, before writing into a target someone else owns.
    validate_install_directory(path)
    state = {"installer": _INSTALLER, "version": _MARKER_VERSION,
             "directory": path, "complete": complete}
    descriptor, temporary = tempfile.mkstemp(prefix=".urbanomy-marker-", dir=path)
    try:
        with os.fdopen(descriptor, "w", encoding="utf-8") as stream:
            json.dump(state, stream, ensure_ascii=False, sort_keys=True)
            stream.write("\n")
        os.replace(temporary, os.path.join(path, INSTALLATION_MARKER))
    finally:
        if os.path.exists(temporary):
            os.unlink(temporary)
    return path
