"""QGIS entry point; scientific dependencies run in a separate interpreter."""


def classFactory(iface):
    from .plugin import UrbanomyPlugin
    return UrbanomyPlugin(iface)
