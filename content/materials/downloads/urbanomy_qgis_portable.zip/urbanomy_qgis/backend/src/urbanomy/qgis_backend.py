"""JSON worker for QGIS, run in the project's modern Python environment.

Usage: ``python -m urbanomy.qgis_backend request.json response.json``.
The QGIS process only exchanges attributes and opaque feature IDs with this
worker; it never imports scientific packages into QGIS's Python interpreter.
"""

from __future__ import annotations

import argparse
from enum import Enum
import json
import math
import os
from pathlib import Path
import re
import socket
import ssl
import tempfile
from typing import Any, Mapping
from urllib.error import HTTPError, URLError
from urllib.parse import urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener


FID_COLUMN = "__urbanomy_fid"
SHARE_COLUMNS = (
    "residential", "business", "recreation", "industrial", "transport",
    "special", "agriculture",
)
VARIABLES = ("footprint_area", "l", "mxi", *SHARE_COLUMNS)
# Same base features and logarithmic target as examples/NSGA2_LLM.ipynb.
FEATURE_COLUMNS = (
    *SHARE_COLUMNS, "share", "footprint_area", "build_floor_area",
    "living_area", "non_living_area", "population", "site_area", "fsi",
    "gsi", "mxi", "l", "area_accessibility", "land_use", "morphotype",
)
CATEGORICAL_COLUMNS = ("land_use", "morphotype")
RADII = (500, 1000, 2000, 3000)
DEFAULT_LLM_URL = "https://routerai.ru/api/v1"
DEFAULT_LLM_MODEL = "deepseek/deepseek-v4-flash"
LLM_TEST_PROMPT = 'Connection test. Return only this JSON object, without markdown or explanation: {"score": 0.5}.'
PROGRESS_PREFIX = "URBANOMY_PROGRESS "


class _NoLLMRedirects(HTTPRedirectHandler):
    def redirect_request(self, request, response, code, message, headers, new_url):
        # A test makes one request, and its Authorization header must never be
        # forwarded to a different endpoint by an automatic redirect.
        return None


urlopen = build_opener(_NoLLMRedirects()).open


class BackendError(ValueError):
    """A validation error suitable for displaying to the user."""


def json_safe(value: Any) -> Any:
    """Convert scientific scalars and unavailable metrics to strict JSON."""
    if value is None:
        return None
    if isinstance(value, Enum):
        return json_safe(value.value)
    if isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, Mapping):
        return {str(key): json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [json_safe(item) for item in value]
    if hasattr(value, "item"):
        return json_safe(value.item())
    # pandas.NA and other optional scalar values.
    if type(value).__name__ in ("NAType", "NaTType"):
        return None
    return str(value)


def default_constraints(site_area: float) -> dict[str, dict[str, Any]]:
    return {
        "footprint_area": {"type": "float", "min": 0.0, "max": 0.1 * site_area},
        "l": {"type": "float", "min": 1.0, "max": 10.0},
        "mxi": {"type": "float", "min": 0.1, "max": 1.0},
        **{name: {"type": "float", "min": 0.0, "max": 1.0} for name in SHARE_COLUMNS},
    }


def validate_constraints(raw: Any, site_area: float) -> dict[str, dict[str, Any]]:
    if raw is None:
        raw = default_constraints(site_area)
    if not isinstance(raw, Mapping) or set(raw) != set(VARIABLES):
        raise BackendError("Ограничения должны содержать footprint_area, l, mxi и все семь долей использования земли.")
    result = {}
    for name in VARIABLES:
        item = raw[name]
        if not isinstance(item, Mapping) or item.get("type", "float") != "float":
            raise BackendError("Тип ограничения для {} должен быть float.".format(name))
        try:
            low, high = float(item["min"]), float(item["max"])
        except (KeyError, TypeError, ValueError) as exc:
            raise BackendError("Укажите численные min и max для {}.".format(name)) from exc
        if not (math.isfinite(low) and math.isfinite(high) and low <= high):
            raise BackendError("Некорректный диапазон {}: min должен быть не больше max.".format(name))
        allowed_low = 1.0 if name == "l" else 0.0
        allowed_high = 0.8 * site_area if name == "footprint_area" else (math.inf if name == "l" else 1.0)
        tolerance = 1e-9 * max(1.0, site_area) if name == "footprint_area" else 1e-12
        if low < allowed_low or high > allowed_high + tolerance:
            raise BackendError("Недопустимые границы для {}.".format(name))
        result[name] = {"type": "float", "min": low, "max": high}
    if sum(result[name]["min"] for name in SHARE_COLUMNS) > 1.0 + 1e-12:
        raise BackendError("Сумма минимальных долей использования земли превышает 1.")
    if sum(result[name]["max"] for name in SHARE_COLUMNS) < 1.0 - 1e-12:
        raise BackendError("Сумма максимальных долей использования земли меньше 1.")
    return result


def bounded_shares(values, lower, upper) -> list[float]:
    """Project onto a simplex while preserving every user-entered bound.

    Simple normalization does not preserve bounds. The clipped-shift projection
    finds shares summing to one, including feasible fixed-share constraints.
    """
    if sum(lower) > 1.0 + 1e-12 or sum(upper) < 1.0 - 1e-12:
        raise BackendError("Ограничения долей несовместимы с суммой 1.")
    left = min(v - hi for v, hi in zip(values, upper)) - 1.0
    right = max(v - lo for v, lo in zip(values, lower)) + 1.0
    for _ in range(80):
        shift = (left + right) / 2.0
        projected = [min(hi, max(lo, v - shift)) for v, lo, hi in zip(values, lower, upper)]
        if sum(projected) > 1.0:
            left = shift
        else:
            right = shift
    projected = [min(hi, max(lo, v - (left + right) / 2.0)) for v, lo, hi in zip(values, lower, upper)]
    # Remove floating point residual without crossing an editable bound.
    residual = 1.0 - sum(projected)
    for i, (lo, hi) in enumerate(zip(lower, upper)):
        delta = min(hi - projected[i], max(lo - projected[i], residual))
        projected[i] += delta
        residual -= delta
    return projected


def _selected_fids(request: Mapping[str, Any], available) -> list[int]:
    selected = request.get("selected_fids", [])
    if not isinstance(selected, list) or any(type(fid) is not int for fid in selected):
        raise BackendError("selected_fids должен быть списком целочисленных QGIS FID.")
    if len(set(selected)) != len(selected) or not set(selected).issubset(set(available)):
        raise BackendError("Выбранный квартал отсутствует в данных или выбран несколько раз.")
    return selected


def _load_blocks(request):
    import geopandas as gpd
    import numpy as np
    import pandas as pd
    from pyproj import CRS
    from shapely import make_valid

    data_path = Path(str(request.get("data_path", ""))).expanduser()
    if not data_path.is_file():
        raise BackendError("Файл данных GeoJSON не найден.")
    with data_path.open(encoding="utf-8") as stream:
        collection = json.load(stream)
    features = collection.get("features", [])
    if collection.get("type") != "FeatureCollection" or not features:
        raise BackendError("Требуется непустой слой кварталов GeoJSON FeatureCollection.")
    fids = [feature.get("properties", {}).get(FID_COLUMN) for feature in features]
    if any(type(fid) is not int for fid in fids) or len(set(fids)) != len(fids):
        raise BackendError("Каждому кварталу требуется уникальный целочисленный __urbanomy_fid.")
    source_crs = request.get("crs")
    if not source_crs:
        source_crs = collection.get("crs", {}).get("properties", {}).get("name") or "EPSG:4326"
    blocks = gpd.GeoDataFrame.from_features(features, crs=CRS.from_user_input(source_crs))
    if blocks.geometry.isna().any() or blocks.geometry.is_empty.any():
        raise BackendError("В слое есть кварталы без геометрии.")
    if not blocks.geometry.geom_type.isin(["Polygon", "MultiPolygon"]).all():
        raise BackendError("Для расчёта требуется полигональный слой кварталов.")
    if not np.isfinite(blocks.total_bounds).all():
        raise BackendError("Координаты кварталов должны быть конечными числами.")
    metric_crs = request.get("metric_crs") or blocks.estimate_utm_crs()
    if metric_crs is None:
        raise BackendError("Не удалось определить метрическую проекцию; укажите metric_crs.")
    metric_crs = CRS.from_user_input(metric_crs)
    if not metric_crs.is_projected or not metric_crs.axis_info or any(
        not math.isclose(axis.unit_conversion_factor, 1.0) for axis in metric_crs.axis_info[:2]
    ):
        raise BackendError("metric_crs должна быть проекцией с единицами в метрах.")
    blocks = blocks.to_crs(metric_crs)
    invalid = ~blocks.geometry.is_valid
    if invalid.any():
        blocks.loc[invalid, "geometry"] = blocks.loc[invalid, "geometry"].map(make_valid)
    blocks["site_area"] = blocks.geometry.area
    if not np.isfinite(blocks["site_area"]).all():
        raise BackendError("Площади кварталов должны быть конечными числами.")
    missing = sorted(set(FEATURE_COLUMNS) - set(blocks.columns))
    if missing:
        raise BackendError("В слое отсутствуют признаки модели: {}.".format(", ".join(missing)))
    for name in FEATURE_COLUMNS:
        if name in CATEGORICAL_COLUMNS:
            continue
        original = blocks[name]
        numeric = pd.to_numeric(original, errors="coerce")
        if (original.notna() & numeric.isna()).any() or np.isinf(numeric).any():
            raise BackendError("Признак {} содержит некорректные числовые значения.".format(name))
        blocks[name] = numeric.astype(float)
    blocks[FID_COLUMN] = fids
    return blocks, int(invalid.sum())


def _load_model(request):
    from catboost import CatBoostRegressor

    path = Path(str(request.get("model_path", ""))).expanduser()
    if not path.is_file():
        raise BackendError("Файл модели CatBoost не найден.")
    model = CatBoostRegressor()
    try:
        model.load_model(str(path))
    except Exception as exc:
        raise BackendError("Не удалось загрузить модель CatBoost .cbm.") from exc
    return model


def _new_estimator(blocks, model):
    from urbanomy.methods.land_value_modeling import LandPriceEstimator

    return LandPriceEstimator(
        blocks=blocks, model=model, orig_features=FEATURE_COLUMNS,
        categorical_features=CATEGORICAL_COLUMNS, radius_list=RADII,
    )


def _predict(estimator, blocks):
    import numpy as np

    predicted = estimator.predict(blocks=blocks)
    values = predicted["land_value"].to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise BackendError("Модель вернула отрицательную или бесконечную стоимость земли. Проверьте модель и признаки.")
    area = predicted["site_area"].to_numpy(dtype=float)
    unit_values = np.full(len(area), np.nan)
    np.divide(values * 100.0, area, out=unit_values, where=area > 0)
    predicted["land_value_per_100m2"] = unit_values
    return predicted


def _attribute_rows(frame, columns):
    return [
        {"fid": int(row[FID_COLUMN]), "attributes": {name: json_safe(row[name]) for name in columns}}
        for _, row in frame.iterrows()
    ]


def _scenario_impact(before, after):
    import numpy as np

    impact = after[[FID_COLUMN, "land_value"]].copy()
    impact["land_value_before"] = before
    impact["d_rub"] = impact["land_value"] - before
    pct = np.full(len(impact), np.nan)
    np.divide(impact["d_rub"].to_numpy() * 100.0, before.to_numpy(), out=pct, where=before.to_numpy() > 0)
    impact["land_value_delta_pct"] = pct
    return _attribute_rows(impact, ("land_value_before", "land_value", "d_rub", "land_value_delta_pct"))


class _OpenAICompatibleClient:
    """Explicit credentials only: no notebook .env or ambient API key lookup."""

    def __init__(self, settings):
        if not isinstance(settings, Mapping):
            raise BackendError("Настройки LLM должны быть объектом JSON.")
        self.api_key = str(settings.get("api_key", "")).strip()
        if not self.api_key:
            raise BackendError("Введите API key для проверки LLM.")
        if any(ord(char) < 32 or ord(char) == 127 for char in self.api_key):
            raise BackendError("API key содержит перенос строки или недопустимый символ; вставьте ключ заново.")
        self.model = str(settings.get("model") or DEFAULT_LLM_MODEL).strip()
        base_url = str(settings.get("base_url") or DEFAULT_LLM_URL).strip().rstrip("/")
        try:
            parts = urlparse(base_url)
            valid_url = parts.scheme in ("http", "https") and parts.hostname and not parts.username and not parts.password
            parts.port  # Also validate a malformed port before creating a request.
        except ValueError:
            valid_url = False
        if not valid_url or any(char.isspace() for char in base_url):
            raise BackendError("Укажите корректный URL OpenAI-совместимого API LLM.")
        if parts.query or parts.fragment:
            raise BackendError("URL LLM не должен содержать параметры запроса или фрагмент.")
        if not self.model or any(ord(char) < 32 or ord(char) == 127 for char in self.model):
            raise BackendError("Укажите корректный идентификатор модели LLM.")
        self.url = base_url if base_url.endswith("/chat/completions") else base_url + "/chat/completions"

    def _detail(self, value):
        """Show only a bounded provider message, with credentials removed."""
        text = str(value or "").replace(self.api_key, "[скрыто]")
        text = re.sub(r"(?i)\bBearer\s+[^\s,;\"']+", "Bearer [скрыто]", text)
        text = re.sub(r"\bsk-[A-Za-z0-9_-]+", "[скрыто]", text)
        text = " ".join(text.split())
        return text[:600]

    def _provider_detail(self, data):
        if not isinstance(data, Mapping):
            return ""
        error = data.get("error")
        if isinstance(error, Mapping):
            message = error.get("message")
            code = error.get("code")
            detail = self._detail(message) if isinstance(message, (str, int, float)) else ""
            if code is not None and isinstance(code, (str, int)):
                detail += " (код: {})".format(self._detail(code))
            metadata = error.get("metadata")
            if isinstance(metadata, Mapping) and isinstance(metadata.get("raw"), str):
                # OpenRouter can wrap the useful provider message inside a JSON
                # string. Extract only its structured error.message, never raw.
                try:
                    provider = json.loads(metadata["raw"][:65536])
                    provider_error = provider.get("error") if isinstance(provider, Mapping) else None
                    provider_message = provider_error.get("message") if isinstance(provider_error, Mapping) else None
                    if isinstance(provider_message, str):
                        detail += "; " + self._detail(provider_message)
                except ValueError:
                    pass
            return detail.strip()[:900]
        return self._detail(error) if isinstance(error, str) else ""

    def _http_error(self, status, detail=""):
        explanation = {
            400: "API отклонил параметры запроса. Проверьте идентификатор модели и сообщение сервиса.",
            401: "API отклонил авторизацию. Проверьте ключ, выбранный сервис (URL) и передачу заголовка Authorization.",
            402: "Недостаточно средств или кредитов у API-провайдера. Проверьте баланс аккаунта.",
            403: "Доступ запрещён. Проверьте права ключа, доступ к модели и ограничения провайдера.",
            404: "URL API или модель не найдены. Проверьте базовый URL и точный идентификатор модели.",
            408: "Сервис не успел обработать запрос. Повторите проверку позже.",
            413: "Сервис отклонил слишком большой запрос.",
            429: "Превышен лимит запросов или квота API. Проверьте квоту и повторите проверку позже.",
        }.get(status)
        if explanation is None:
            if 300 <= status < 400:
                explanation = "API вернул перенаправление. Укажите конечный URL API; ключ не пересылается автоматически."
            elif status >= 500:
                explanation = "Ошибка на стороне API-провайдера. Повторите проверку позже или выберите доступную модель."
            else:
                explanation = "API отклонил запрос. Проверьте настройки и сообщение сервиса."
        message = "Ошибка LLM: HTTP {}. {}".format(status, explanation)
        message += " Адрес запроса: {}. Модель: {}.".format(self._detail(self.url), self._detail(self.model))
        if status == 401 and urlparse(self.url).hostname == "openrouter.ai":
            message += " Для ключа RouterAI укажите URL https://routerai.ru/api/v1."
        if detail:
            message += " Ответ сервиса: " + detail
        return BackendError(message)

    def _provider_failure(self, data):
        error = data.get("error")
        code = error.get("code") if isinstance(error, Mapping) else None
        try:
            status = int(code)
        except (ValueError, TypeError):
            status = None
        detail = self._provider_detail(data)
        if status is not None and 300 <= status <= 599:
            return self._http_error(status, detail)
        return BackendError("Ошибка LLM: сервис вернул ошибку{}".format(": " + detail if detail else ". Проверьте настройки API."))

    def invoke(self, prompt, *, timeout=120):
        payload = json.dumps({
            # Some reasoning models reject temperature, so use provider defaults.
            "model": self.model,
            "messages": [{"role": "user", "content": prompt}],
        }, ensure_ascii=False).encode("utf-8")
        request = Request(self.url, data=payload, headers={
            "Authorization": "Bearer " + self.api_key, "Content-Type": "application/json",
        })
        try:
            with urlopen(request, timeout=timeout) as response:
                # An API response is small; never copy an unbounded error body
                # into a QGIS dialog or response file.
                raw_response = response.read(1024 * 1024 + 1)
        except HTTPError as exc:
            try:
                detail = self._provider_detail(json.loads(exc.read(65536)))
            except (ValueError, UnicodeError, OSError):
                detail = ""
            finally:
                exc.close()
            raise self._http_error(exc.code, detail) from exc
        except (TimeoutError, socket.timeout) as exc:
            raise BackendError("Ошибка LLM: время ожидания ответа истекло. Проверьте соединение и доступность модели.") from exc
        except (ssl.SSLError, URLError) as exc:
            reason = exc.reason if isinstance(exc, URLError) else exc
            if isinstance(reason, ssl.SSLError):
                message = "Ошибка LLM: не удалось проверить TLS-сертификат API. Проверьте сертификаты выбранного Python, дату системы и прокси."
            elif isinstance(reason, (TimeoutError, socket.timeout)):
                message = "Ошибка LLM: время ожидания ответа истекло. Проверьте соединение и доступность модели."
            elif isinstance(reason, socket.gaierror):
                message = "Ошибка LLM: не удалось найти сервер (DNS). Проверьте домен в URL, интернет и настройки прокси."
            else:
                message = "Ошибка LLM: не удалось соединиться с API. Проверьте URL, интернет, VPN или прокси."
            raise BackendError(message) from exc
        except OSError as exc:
            raise BackendError("Ошибка LLM: соединение с API прервано. Проверьте интернет и доступность сервиса.") from exc
        except Exception as exc:
            # Unexpected transport errors may echo request headers: do not show
            # arbitrary exception text or raw response bodies.
            raise BackendError("Ошибка LLM: не удалось выполнить запрос к API. Проверьте настройки подключения.") from exc
        if len(raw_response) > 1024 * 1024:
            raise BackendError("Ошибка LLM: ответ API превышает допустимый размер 1 МБ.")
        try:
            data = json.loads(raw_response)
        except (ValueError, UnicodeError) as exc:
            raise BackendError("Ошибка LLM: API вернул ответ не в формате JSON. Проверьте URL: нужен OpenAI-совместимый /chat/completions.") from exc
        if not isinstance(data, Mapping):
            raise BackendError("Ошибка LLM: ответ API должен быть объектом JSON с choices[0].message.content.")
        if data.get("error") is not None:
            raise self._provider_failure(data)
        choices = data.get("choices")
        if not isinstance(choices, list) or not choices or not isinstance(choices[0], Mapping):
            raise BackendError("Ошибка LLM: API не вернул choices[0]. Проверьте URL и совместимость API с Chat Completions.")
        choice = choices[0]
        if choice.get("error") is not None or choice.get("finish_reason") == "error":
            raise self._provider_failure(choice)
        if choice.get("finish_reason") in ("length", "max_tokens"):
            raise BackendError("Ошибка LLM: ответ модели обрезан (finish_reason=length). Увеличьте лимит ответа у провайдера или выберите другую модель.")
        message = choice.get("message")
        if not isinstance(message, Mapping):
            raise BackendError("Ошибка LLM: в ответе API отсутствует choices[0].message.")
        if message.get("refusal") or choice.get("finish_reason") == "content_filter":
            raise BackendError("Ошибка LLM: модель отказалась отвечать или ответ заблокирован фильтром провайдера. Проверьте промпт или выберите другую модель.")
        content = message.get("content")
        if not isinstance(content, str) or not content.strip():
            raise BackendError("Ошибка LLM: модель вернула пустой текст вместо JSON score. Проверьте модель и лимиты ответа.")
        content = content.strip()
        # Accept one conventional JSON fence, but do not extract arbitrary text
        # or invent a score from malformed model output.
        fenced = re.fullmatch(r"```(?:json)?\s*\n?(.+?)\n?```", content, flags=re.DOTALL | re.IGNORECASE)
        if fenced:
            content = fenced.group(1).strip()
        try:
            parsed = json.loads(content)
        except ValueError as exc:
            raise BackendError('Ошибка LLM: модель ответила текстом или некорректным JSON. Требуется объект {"score": 0.5} со значением от 0 до 1.') from exc
        if not isinstance(parsed, Mapping) or "score" not in parsed:
            raise BackendError('Ошибка LLM: в JSON модели отсутствует поле score. Требуется объект {"score": 0.5}.')
        score = parsed["score"]
        if isinstance(score, bool) or not isinstance(score, (int, float)) or not 0 <= score <= 1 or not math.isfinite(score):
            raise BackendError("Ошибка LLM: score должен быть числом от 0 до 1; строки, null, NaN и значения вне диапазона не подходят.")
        return {"score": float(score)}


def _optimizer_parameters(request):
    try:
        pop_size, n_gen = request.get("pop_size", 20), request.get("n_gen", 20)
        seed = request.get("seed", 42)
        if any(type(value) is not int for value in (pop_size, n_gen, seed)):
            raise ValueError
        if pop_size < 2 or n_gen < 1:
            raise ValueError
    except (TypeError, ValueError) as exc:
        raise BackendError("pop_size должен быть целым числом ≥ 2, n_gen — ≥ 1, seed — целым числом.") from exc
    return pop_size, n_gen, seed


def _investment_parameters(raw):
    from urbanomy.methods.investment_potential.constants import DEFAULT_BENCHMARKS_RU, DEFAULT_DISCOUNT_RATE

    if raw is None:
        raw = {}
    if not isinstance(raw, Mapping) or set(raw) - {"discount_rate", "benchmarks"}:
        raise BackendError("Некорректные параметры инвестиционного расчёта.")
    rate = raw.get("discount_rate", DEFAULT_DISCOUNT_RATE)
    if type(rate) not in (int, float) or not 0 <= rate <= 10:
        raise BackendError("Ставка дисконтирования должна быть от 0 до 1000%.")
    profiles = {key.value: dict(value) for key, value in DEFAULT_BENCHMARKS_RU.items()}
    overrides = raw.get("benchmarks", {})
    if not isinstance(overrides, Mapping) or set(overrides) - set(profiles):
        raise BackendError("Неизвестный тип застройки в финансовых нормативах.")
    for land_use, values in overrides.items():
        if not isinstance(values, Mapping) or set(values) - set(profiles[land_use]):
            raise BackendError("Неизвестный финансовый норматив для {}.".format(land_use))
        for key, value in values.items():
            if type(value) not in (int, float) or not 0 <= value <= 1e15:
                raise BackendError("Финансовый норматив {} должен быть неотрицательным числом до 10¹⁵.".format(key))
            if key.endswith("_years"):
                if not float(value).is_integer() or not 1 <= value <= 100:
                    raise BackendError("Срок должен быть целым числом от 1 до 100 лет.")
                value = int(value)
            profiles[land_use][key] = value
    return {"discount_rate": float(rate), "benchmarks": profiles}


def _objective_statistics(objectives):
    """Use the notebook's positive objective min/median/max, without evaluating."""
    import numpy as np

    values = np.asarray(objectives, dtype=float)
    if values.ndim != 2 or not len(values):
        return {}
    stats = {"population": len(values)}
    for column, name in enumerate(("land", "npv", "ser")):
        if column >= values.shape[1]:
            break
        scores = -values[:, column]
        if np.all(np.isfinite(scores)):
            stats.update({
                name + "_min": float(np.min(scores)),
                name + "_median": float(np.median(scores)),
                name + "_max": float(np.max(scores)),
            })
    return stats


def _progress_event(progress, phase, generation, n_gen, evaluations, **stats):
    if progress is not None:
        progress({
            "version": 1, "operation": "optimize", "phase": phase,
            "generation": int(generation), "n_gen": int(n_gen),
            "evaluations": int(evaluations), **stats,
        })


def _write_progress(event):
    # Only numeric optimizer statistics and fixed protocol labels reach stdout;
    # no request, API response, prompt, credential or candidate attributes.
    print(PROGRESS_PREFIX + json.dumps(event, ensure_ascii=False, allow_nan=False), flush=True)


def _optimise(request, blocks, model, estimator, baseline, progress=None):
    import numpy as np
    from blocksnet.enums import LandUse
    from pymoo.algorithms.moo.nsga2 import NSGA2
    from pymoo.core.callback import Callback
    from pymoo.optimize import minimize
    from urbanomy.methods.land_value_modeling import DistrictProblem, ScenarioTEPModifier, StrategicAlignmentScorer
    from urbanomy.methods.investment_potential import calculate_investment_metrics

    selected = _selected_fids(request, blocks[FID_COLUMN])
    if len(selected) != 1:
        raise BackendError("Для оптимизации выберите ровно один квартал.")
    target_fid = selected[0]
    target_label = blocks.index[blocks[FID_COLUMN] == target_fid][0]
    if float(blocks.at[target_label, "site_area"]) <= 0:
        raise BackendError("Для оптимизации выберите квартал с положительной площадью.")
    constraints = validate_constraints(request.get("constraints"), float(blocks.at[target_label, "site_area"]))
    objective = request.get("objective", "land_value")
    objective_index = {"land_value": 0, "investor_npv": 1, "llm_score": 2}
    if objective not in objective_index:
        raise BackendError("Неизвестный критерий выбора результата оптимизации.")
    settings = request.get("llm") or {}
    if not isinstance(settings, Mapping):
        raise BackendError("Настройки LLM должны быть объектом JSON.")
    has_key = bool(request.get("use_llm", False)) and bool(str(settings.get("api_key", "")).strip())
    prompt = str(request.get("prompt", "")).strip() if has_key else ""
    if objective == "llm_score" and (not has_key or not prompt):
        raise BackendError("Для критерия LLM требуются API key и непустой промпт.")
    scorer = None
    if has_key and prompt:
        scorer = StrategicAlignmentScorer(
            llm=_OpenAICompatibleClient(settings),
            prompt=prompt + '\nReturn only valid JSON, no markdown: {"score": 0.0}. Score must be between 0 and 1.',
        )
    pop_size, n_gen, seed = _optimizer_parameters(request)
    investment_parameters = _investment_parameters(request.get("investment_parameters"))

    working = blocks.copy()
    # Acquisition and demolition refer to the original state, including across
    # repeated optimisations. Preserve an earlier baseline when it exists.
    for name, source in (
        ("land_value_before", baseline["land_value"]),
        ("build_floor_area_before", blocks["build_floor_area"]),
        ("land_use_before", blocks["land_use"]),
    ):
        if name not in working:
            working[name] = source
        else:
            working[name] = working[name].where(working[name].notna(), source)

    class PluginDistrictProblem(DistrictProblem):
        def __init__(self):
            super().__init__(
                blocks=working, model=model,
                estimator_kwargs={"orig_features": FEATURE_COLUMNS, "categorical_features": CATEGORICAL_COLUMNS},
                constraints=constraints, target_id=target_fid,
                target_id_column=FID_COLUMN, strategic_alignment_scorer=scorer,
            )
            self.var_names = [name for name in VARIABLES if constraints[name]["min"] < constraints[name]["max"]]
            self.n_var = len(self.var_names)
            self.xl = np.array([constraints[name]["min"] for name in self.var_names])
            self.xu = np.array([constraints[name]["max"] for name in self.var_names])
            self._baseline_land_value = float(baseline["land_value"].sum())
            self.evaluations = {}

        def _repair_genome(self, genome):
            repaired = {
                name: float(np.clip(genome.get(name, constraints[name]["min"]), constraints[name]["min"], constraints[name]["max"]))
                for name in VARIABLES
            }
            shares = bounded_shares(
                [repaired[name] for name in SHARE_COLUMNS],
                [constraints[name]["min"] for name in SHARE_COLUMNS],
                [constraints[name]["max"] for name in SHARE_COLUMNS],
            )
            repaired.update(zip(SHARE_COLUMNS, shares))
            repaired["share"] = repaired["residential"]
            repaired["land_use"] = LandUse[max(SHARE_COLUMNS, key=lambda name: repaired[name]).upper()]
            footprint, floors, mxi = repaired["footprint_area"], repaired["l"], repaired["mxi"]
            build = footprint * floors
            repaired.update({
                "build_floor_area": build, "living_area": build * mxi,
                "non_living_area": build * (1.0 - mxi), "population": build * mxi / 20.0,
                "fsi": build / float(working.at[target_label, "site_area"]),
                "gsi": footprint / float(working.at[target_label, "site_area"]),
            })
            repaired["morphotype"] = self._recompute_morphotype(repaired)
            return repaired

        def scenario(self, changes):
            after = ScenarioTEPModifier(self.blocks).apply(target_fid, changes, target_id_column=FID_COLUMN)
            # The modifier computes ratios 0/0 for an empty building. Keep the
            # entered design parameters finite even at a zero-footprint bound.
            after.at[target_label, "l"] = changes["l"]
            after.at[target_label, "mxi"] = changes["mxi"]
            return after

        def candidate(self, vector):
            changes = self._repair_genome(dict(zip(self.var_names, vector)))
            cache_key = json.dumps(json_safe(changes), sort_keys=True)
            if cache_key not in self.evaluations:
                after = self.scenario(changes)
                priced = _predict(estimator, after)
                land_value = float(priced["land_value"].sum())
                project = priced.loc[[target_label]].copy()
                project["is_project"] = True
                summary = calculate_investment_metrics(
                    project, **investment_parameters, show_project_totals=False, show_warning=False)
                investor_npv = float(summary["NPV"].iloc[0])
                if not math.isfinite(investor_npv):
                    raise BackendError("Не удалось рассчитать NPV выбранного квартала.")
                scores = [land_value, investor_npv]
                if scorer is not None:
                    scores.append(float(scorer.score_candidate(
                        params_repaired=changes,
                        land_value_gain=land_value - self._baseline_land_value,
                        investor_npv=investor_npv,
                    )["score"]))
                self.evaluations[cache_key] = (changes, scores)
            return self.evaluations[cache_key]

        def _evaluate(self, X, out, *args, **kwargs):
            out["F"] = np.array([[-score for score in self.candidate(vector)[1]] for vector in X])

    problem = PluginDistrictProblem()
    last_generation, last_stats = 0, {}

    class GenerationProgress(Callback):
        def notify(self, algorithm):
            nonlocal last_generation, last_stats
            last_generation = int(algorithm.n_gen)
            last_stats = _objective_statistics(algorithm.pop.get("F"))
            _progress_event(progress, "generation", last_generation, n_gen, len(problem.evaluations), **last_stats)
            if last_generation < n_gen and not algorithm.termination.has_terminated():
                _progress_event(progress, "start", last_generation + 1, n_gen, len(problem.evaluations))

    if problem.n_var == 0:
        _progress_event(progress, "fixed", 0, n_gen, 0)
        fixed_scores = problem.candidate([])[1]
        candidates = [([], fixed_scores)]
        last_stats = _objective_statistics([[-score for score in fixed_scores]])
        _progress_event(progress, "fixed", 0, n_gen, len(problem.evaluations), **last_stats)
    else:
        _progress_event(progress, "start", 1, n_gen, 0)
        result = minimize(
            problem, NSGA2(pop_size=pop_size, eliminate_duplicates=True),
            ("n_gen", n_gen), seed=seed, verbose=False, save_history=False,
            callback=GenerationProgress(),
        )
        if result.X is None or result.F is None:
            raise BackendError("Оптимизатор не нашёл допустимых вариантов.")
        vectors = np.atleast_2d(result.X)
        candidates = [(vector, problem.candidate(vector)[1]) for vector in vectors]
    best_vector, scores = max(candidates, key=lambda item: item[1][objective_index[objective]])
    changes, _ = problem.candidate(best_vector)
    after = problem.scenario(changes)
    _progress_event(progress, "finalize", last_generation, n_gen, len(problem.evaluations), **last_stats)
    columns = [
        *VARIABLES, "land_use", "share", "build_floor_area", "living_area",
        "non_living_area", "population", "fsi", "gsi", "morphotype",
        "site_area", "land_value_before", "land_use_before", "build_floor_area_before",
    ]
    result = {
        "rows": _attribute_rows(after.loc[[target_label]], columns),
        "summary": {
            "objective": objective, "pop_size": pop_size, "n_gen": n_gen,
            "evaluations": len(problem.evaluations), "pareto_size": len(candidates),
            "land_value_total": scores[0], "land_value_gain": scores[0] - problem._baseline_land_value,
            "investor_npv": scores[1], "llm_score": scores[2] if scorer else None,
            "discount_rate": investment_parameters["discount_rate"],
            "llm_used": scorer is not None,
        },
    }
    if request.get("show_scenario_impact"):
        result["impact_rows"] = _scenario_impact(baseline["land_value"], _predict(estimator, after))
    return result


def run_request(request: Mapping[str, Any], progress=None) -> dict[str, Any]:
    """Execute an operation without touching any QGIS layer or credentials file."""
    if not isinstance(request, Mapping):
        raise BackendError("Запрос должен быть объектом JSON.")
    operation = request.get("operation")
    if operation == "test_llm":
        # Connection checks have no layer, CatBoost model or scientific imports.
        # The fixed prompt is the only request: no retry or follow-up completion.
        client = _OpenAICompatibleClient(request.get("llm") or {})
        result = client.invoke(LLM_TEST_PROMPT, timeout=60)
        return {"ok": True, "version": 1, "operation": operation, "summary": {
            "model": client._detail(client.model), "endpoint": client._detail(client.url),
            "score": result["score"], "requests": 1,
        }}
    if operation not in ("estimate", "optimize", "investment", "impact"):
        raise BackendError("Неизвестная операция. Допустимы estimate, optimize, investment, impact и test_llm.")
    if operation == "optimize":
        _, n_gen, _ = _optimizer_parameters(request)
        _progress_event(progress, "prepare", 0, n_gen, 0)
    blocks, repaired_count = _load_blocks(request)
    if operation == "impact":
        import pandas as pd
        import numpy as np

        column = request.get("before_column")
        if not isinstance(column, str) or column not in blocks:
            raise BackendError("Выберите столбец с сохранённой полной стоимостью земли до изменения квартала.")
        before = pd.to_numeric(blocks[column], errors="coerce")
        if not np.isfinite(before.to_numpy(dtype=float)).all() or (before < 0).any():
            raise BackendError("Исходная стоимость должна быть неотрицательным числом для каждого квартала. Сначала рассчитайте стоимость всего слоя.")
    model = _load_model(request)
    estimator = _new_estimator(blocks, model)
    baseline = _predict(estimator, blocks)
    if operation == "estimate":
        result = {
            "rows": _attribute_rows(baseline, ("site_area", "land_value", "land_value_per_100m2")),
            "summary": {"count": len(baseline), "land_value_total": float(baseline["land_value"].sum())},
        }
    elif operation == "optimize":
        result = _optimise(request, blocks, model, estimator, baseline, progress=progress)
    elif operation == "impact":
        result = {"rows": _scenario_impact(before, baseline),
                  "summary": {"count": len(baseline), "land_value_gain": float((baseline["land_value"] - before).sum())}}
    else:
        from urbanomy.methods.investment_potential import calculate_investment_metrics

        selected = _selected_fids(request, blocks[FID_COLUMN])
        project = baseline.loc[baseline[FID_COLUMN].isin(selected)].copy() if selected else baseline.copy()
        # The report must include the user's selection (or all blocks), even
        # when an existing is_project column marks only a previous scenario.
        project["is_project"] = True
        parameters = _investment_parameters(request.get("investment_parameters"))
        metrics = calculate_investment_metrics(project, **parameters, show_project_totals=False, show_warning=False)
        fids = project[FID_COLUMN].tolist()
        if len(metrics) != len(fids):
            raise BackendError("Число строк инвестиционного отчёта не совпало с выбранными кварталами.")
        result = {
            "columns": list(metrics.columns),
            "rows": [{"fid": int(fid), "attributes": json_safe(row.to_dict())}
                     for fid, (_, row) in zip(fids, metrics.iterrows())],
            "summary": {"count": len(metrics), "discount_rate": parameters["discount_rate"]},
        }
    result.setdefault("summary", {}).update({
        "metric_crs": blocks.crs.to_string(), "repaired_geometries": repaired_count,
        "zero_area_count": int((blocks["site_area"] <= 0).sum()),
    })
    return json_safe({"ok": True, "version": 1, "operation": operation, **result})


def _error_text(exc, request):
    if isinstance(exc, ImportError):
        message = "В выбранном Python отсутствуют зависимости Urbanomy. Установите проект в отдельное окружение Python 3.10–3.13."
    else:
        message = str(exc) or type(exc).__name__
    if isinstance(request, Mapping):
        settings = request.get("llm")
        if isinstance(settings, Mapping) and settings.get("api_key"):
            message = message.replace(str(settings["api_key"]), "[скрыто]")
    return message[:2000]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("request", type=Path)
    parser.add_argument("response", type=Path)
    args = parser.parse_args(argv)
    # Eager plotting dependencies should use a writable cache and never show a
    # GUI in this subprocess. Only the explicit URBANOMY_API_KEY handoff below
    # supplies credentials; notebook .env and provider environment keys do not.
    os.environ.setdefault("MPLBACKEND", "Agg")
    cache_root = Path(tempfile.gettempdir()) / "urbanomy-qgis-cache"
    os.environ.setdefault("MPLCONFIGDIR", str(cache_root / "matplotlib"))
    os.environ.setdefault("XDG_CACHE_HOME", str(cache_root))
    request = None
    try:
        with args.request.open(encoding="utf-8") as stream:
            request = json.load(stream)
        # The desktop UI keeps the key in memory and supplies it only to this
        # child process. Request/response files never need contain a secret.
        if isinstance(request, Mapping) and request.get("use_llm"):
            request = dict(request)
            request["llm"] = dict(request.get("llm") or {})
            request["llm"]["api_key"] = os.environ.get("URBANOMY_API_KEY", "")
        if isinstance(request, Mapping) and request.get("operation") == "optimize":
            result = run_request(request, progress=_write_progress)
        else:
            result = run_request(request)
        status = 0
    except Exception as exc:
        result = {"ok": False, "version": 1, "error": _error_text(exc, request)}
        status = 1
    # Avoid a half-written response being interpreted after process completion.
    args.response.parent.mkdir(parents=True, exist_ok=True)
    with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=args.response.parent, delete=False) as stream:
        json.dump(result, stream, ensure_ascii=False, allow_nan=False)
        temporary = stream.name
    os.replace(temporary, args.response)
    return status


if __name__ == "__main__":
    raise SystemExit(main())
