"""One asynchronous LLM request, independent of map layers and CatBoost."""

import json
import math
import os
import shutil
import tempfile
from urllib.parse import urlparse

from qgis.PyQt.QtCore import QProcess, QProcessEnvironment, QTimer, Qt
from qgis.PyQt.QtWidgets import (
    QDialog, QHBoxLayout, QLabel, QPlainTextEdit, QPushButton, QVBoxLayout,
)


class LLMCheckDialog(QDialog):
    """Run the bundled worker once with an in-memory API key."""

    def __init__(self, parent, configuration, plugin_directory):
        super(LLMCheckDialog, self).__init__(parent)
        self.setWindowTitle("Проверка LLM")
        self.resize(720, 400)
        self._configuration = dict(configuration or {})
        self._plugin_directory = os.path.abspath(plugin_directory)
        self._api_key = str(self._configuration.pop("api_key", "") or "").strip()
        self._temporary = None
        self._response_path = None
        self._closing = False
        self._started = False
        self.process = None
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._timeout)

        layout = QVBoxLayout(self)
        description = QLabel(
            "Проверка отправляет один короткий запрос с введёнными ключом, URL "
            "и моделью. Ответ должен содержать JSON с оценкой score от 0 до 1. "
            "Кварталы и модель CatBoost для проверки не нужны."
        )
        description.setWordWrap(True)
        layout.addWidget(description)
        self.status_label = QLabel("Подготовка проверки…")
        self.status_label.setWordWrap(True)
        self.status_label.setTextFormat(Qt.PlainText)
        layout.addWidget(self.status_label)
        self.result = QPlainTextEdit()
        self.result.setReadOnly(True)
        layout.addWidget(self.result)
        buttons = QHBoxLayout()
        buttons.addStretch()
        self.close_button = QPushButton("Отмена")
        self.close_button.clicked.connect(self.reject)
        buttons.addWidget(self.close_button)
        layout.addLayout(buttons)
        QTimer.singleShot(0, self._start)

    def _validated_configuration(self):
        if not self._api_key:
            raise ValueError("Введите API-ключ LLM в настройках и повторите проверку.")
        raw_python = str(self._configuration.get("python_path") or "").strip()
        python_path = os.path.abspath(os.path.expanduser(raw_python))
        if not raw_python or not os.path.isfile(python_path) or not os.access(python_path, os.X_OK):
            raise ValueError("Укажите исполняемый Python отдельного окружения Urbanomy.")
        base_url = str(self._configuration.get("llm_base_url") or "").strip().rstrip("/")
        try:
            parsed = urlparse(base_url)
            valid_url = (parsed.scheme in ("http", "https") and parsed.hostname
                         and not parsed.username and not parsed.password
                         and not parsed.query and not parsed.fragment)
            parsed.port
        except ValueError:
            valid_url = False
        if not valid_url:
            raise ValueError("Укажите URL API с http:// или https://, без ключа, параметров и фрагмента.")
        model = str(self._configuration.get("llm_model") or "").strip()
        if not model:
            raise ValueError("Укажите идентификатор модели LLM у выбранного провайдера.")
        return python_path, base_url, model

    def _resolve_backend(self):
        for directory in (
            os.path.join(self._plugin_directory, "backend", "src"),
            os.path.abspath(os.path.join(self._plugin_directory, "..", "..", "src")),
        ):
            if os.path.isfile(os.path.join(directory, "urbanomy", "qgis_backend.py")):
                return directory
        raise ValueError("В плагине отсутствует вычислительный модуль. Обновите плагин из полного ZIP.")

    def _process_environment(self, backend_directory):
        environment = QProcessEnvironment.systemEnvironment()
        for name in (
            "PYTHONHOME", "PYTHONPATH", "QT_PLUGIN_PATH", "QT_QPA_PLATFORM_PLUGIN_PATH",
            "QT_QPA_PLATFORM", "QT_QPA_FONTDIR", "QGIS_PREFIX_PATH", "URBANOMY_API_KEY",
        ):
            environment.remove(name)
        environment.insert("PYTHONPATH", backend_directory)
        environment.insert("PYTHONNOUSERSITE", "1")
        environment.insert("PYTHONUTF8", "1")
        environment.insert("PYTHONUNBUFFERED", "1")
        environment.insert("URBANOMY_API_KEY", self._api_key)
        return environment

    def _start(self):
        if self._closing or self._started:
            return
        self._started = True
        try:
            python_path, base_url, model = self._validated_configuration()
            backend_directory = self._resolve_backend()
            self._temporary = tempfile.mkdtemp(prefix="urbanomy_llm_check_")
            request_path = os.path.join(self._temporary, "request.json")
            self._response_path = os.path.join(self._temporary, "response.json")
            request = {"operation": "test_llm", "use_llm": True,
                       "llm": {"base_url": base_url, "model": model}}
            descriptor = os.open(request_path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
            with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                json.dump(request, handle, ensure_ascii=False, allow_nan=False)
            process = QProcess(self)
            self.process = process
            process.setProcessChannelMode(QProcess.MergedChannels)
            process.setProcessEnvironment(self._process_environment(backend_directory))
            process.setWorkingDirectory(self._temporary)
            process.readyReadStandardOutput.connect(lambda: self._drain_output(process))
            process.finished.connect(lambda code, status: self._finished(process, code, status))
            process.errorOccurred.connect(lambda error: self._process_error(process, error))
            self.status_label.setText("Отправляется один запрос. Ожидание ответа…")
            process.start(python_path, ["-m", "urbanomy.qgis_backend", request_path, self._response_path])
            if self.process is process:
                self._timer.start(75000)
        except (OSError, ValueError) as error:
            self._complete(False, str(error))

    def _drain_output(self, process):
        # A child library may log credentials: only the sanitised protocol is shown.
        if process is self.process:
            process.readAllStandardOutput()

    def _process_error(self, process, error):
        if process is self.process and error == QProcess.FailedToStart:
            self._complete(False, "Не удалось запустить Python. Проверьте путь в настройках Urbanomy.")

    def _finished(self, process, exit_code, exit_status):
        if process is not self.process or self._closing:
            return
        self._drain_output(process)
        try:
            if not self._response_path or not os.path.isfile(self._response_path):
                raise ValueError(
                    "Python не вернул результат проверки (код {}). "
                    "Проверьте окружение Urbanomy и обновите плагин из полного ZIP.".format(exit_code)
                )
            with open(self._response_path, "r", encoding="utf-8") as handle:
                response = json.loads(handle.read(131072))
            if not isinstance(response, dict):
                raise ValueError("Python вернул некорректный результат проверки.")
            if not response.get("ok"):
                raise ValueError(str(response.get("error") or "API не подтвердил успешный ответ."))
            if exit_code != 0 or exit_status != QProcess.NormalExit:
                raise ValueError("Процесс Python завершился с ошибкой (код {}).".format(exit_code))
            summary = response.get("summary")
            if not isinstance(summary, dict) or summary.get("requests") != 1:
                raise ValueError("Python вернул некорректное подтверждение одного запроса.")
            score = summary.get("score")
            if isinstance(score, bool) or not isinstance(score, (int, float)) or not math.isfinite(score) or not 0 <= score <= 1:
                raise ValueError("Ответ API не содержит корректную оценку score от 0 до 1.")
            message = (
                "Ключ, URL и модель работают. Получен корректный JSON.\n\n"
                "Модель: {}\nАдрес запроса: {}\nОценка score: {}\nЗапросов: 1"
            ).format(summary.get("model", ""), summary.get("endpoint", ""), score)
            self._complete(True, message)
        except (OSError, ValueError, TypeError) as error:
            self._complete(False, str(error))

    def _complete(self, success, message):
        if self._closing:
            return
        self._cleanup()
        self.status_label.setText("Проверка успешна" if success else "Проверка не пройдена")
        message = str(message)
        if not success and "Адрес запроса:" not in message:
            base_url = str(self._configuration.get("llm_base_url") or "").strip().rstrip("/")
            endpoint = base_url if base_url.endswith("/chat/completions") else base_url + "/chat/completions"
            model = str(self._configuration.get("llm_model") or "").strip()
            message = "URL API: {}\nМодель: {}\n\n{}".format(endpoint if base_url else "не указан", model or "не указана", message)
        if self._api_key:
            message = message.replace(self._api_key, "[API key скрыт]")
        self.result.setPlainText(message[:8000])
        self.close_button.setText("Закрыть")

    def _timeout(self):
        if self.process is not None and not self._closing:
            self._complete(
                False, "Время ожидания истекло. Проверьте сеть и доступность API; повторных запросов не было.",
            )

    def _cleanup(self):
        self._timer.stop()
        process = self.process
        self.process = None
        if process is not None:
            process.blockSignals(True)
            if process.state() != QProcess.NotRunning:
                process.kill()
                process.waitForFinished(1000)
            process.deleteLater()
        temporary = self._temporary
        self._temporary = None
        self._response_path = None
        if temporary:
            shutil.rmtree(temporary, ignore_errors=True)

    def reject(self):
        self._closing = True
        self._cleanup()
        super(LLMCheckDialog, self).reject()
