"""Small, Python 3.6-compatible helpers shared by the QGIS interface."""

import hashlib
import json
import math

FID_FIELD = "__urbanomy_fid"


def json_value(value):
    if value is None or isinstance(value, (str, bool, int)):
        return value
    if isinstance(value, float):
        return value if math.isfinite(value) else None
    if isinstance(value, (list, tuple)):
        return [json_value(item) for item in value]
    if isinstance(value, dict):
        return {str(key): json_value(item) for key, item in value.items()}
    if hasattr(value, "isNull") and value.isNull():
        return None
    if hasattr(value, "toPyDateTime"):
        return value.toPyDateTime().isoformat()
    if hasattr(value, "toPyDate"):
        return value.toPyDate().isoformat()
    return str(value)


def fingerprint(data):
    encoded = json.dumps(data, sort_keys=True, ensure_ascii=False,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def next_price_fields(existing, total="land_value", unit="lv100m2"):
    """Reserve selected history fields without overwriting layer attributes."""
    selected = [name for name in (total, unit) if name is not None]
    if not selected or any(not isinstance(name, str) or not name.strip()
                           or any(ord(char) < 32 or ord(char) == 127 for char in name)
                           or len(name) > 63 or name.casefold() in
                           {FID_FIELD, "geometry", "site_area"} for name in selected):
        raise ValueError("Укажите непустое название колонки до 63 символов без переносов строк. "
                         "Имена site_area, geometry и __urbanomy_fid зарезервированы.")
    if len({name.casefold() for name in selected}) != len(selected):
        raise ValueError("Названия колонок должны различаться.")
    names = {name.casefold() for name in existing}
    number = 1
    while True:
        suffix = "" if number == 1 else "_{}".format(number)
        fields = tuple(name + suffix if name is not None else None for name in (total, unit))
        if all(name is None or name.casefold() not in names for name in fields):
            return fields
        number += 1


def validate_result_rows(rows, expected_fids):
    if not isinstance(rows, list) or not rows:
        raise ValueError("Вычислитель не вернул результаты.")
    fids = []
    for row in rows:
        if not isinstance(row, dict) or not isinstance(row.get("fid"), int):
            raise ValueError("Некорректный идентификатор результата.")
        if not isinstance(row.get("attributes"), dict):
            raise ValueError("Некорректные атрибуты результата.")
        for value in row["attributes"].values():
            if isinstance(value, float) and not math.isfinite(value):
                raise ValueError("Результат содержит бесконечное значение.")
        fids.append(row["fid"])
    if len(fids) != len(set(fids)) or set(fids) != set(expected_fids):
        raise ValueError("Результат не соответствует кварталам исходного слоя.")
