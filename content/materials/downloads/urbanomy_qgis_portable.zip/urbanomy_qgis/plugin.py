"""Urbanomy UI for QGIS 3.4 / Qt 5. All layer access stays on the UI thread."""

import json
import math
import os
import shutil
import tempfile

from qgis.PyQt.QtCore import QProcess, QProcessEnvironment, QSettings, QSize, QTimer, Qt, QVariant
from qgis.PyQt.QtGui import QIcon
from qgis.PyQt.QtWidgets import QAction, QDialog, QInputDialog, QMessageBox, QProgressDialog
from qgis.core import (QgsCoordinateReferenceSystem, QgsCoordinateTransform,
                       QgsFeature, QgsField, QgsFillSymbol, QgsGeometry, QgsProject,
                       QgsRuleBasedRenderer, QgsVectorDataProvider,
                       QgsVectorLayer, QgsWkbTypes)

from .bridge import FID_FIELD, fingerprint, json_value, next_price_fields, validate_result_rows
from .dialogs import (ConstraintsDialog, EstimateDialog, InvestmentDialog,
                      OptimizerDialog, ResultsDialog, SettingsDialog)
from .installer_dialog import InstallerDialog
from .install_support import (default_environment_directory, environment_directory,
                              environment_python, read_installation_marker)
from .llm_check_dialog import LLMCheckDialog


class UrbanomyPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.actions = []
        self.process = None
        self.progress = None
        self.job = None
        self.api_key = ""
        self.alive = True
        self.result_dialogs = []
        self.installer = None
        self.llm_check = None
        self.investment_parameters = None
        self.directory = os.path.dirname(__file__)
        self.settings = QSettings()

    def initGui(self):
        self.toolbar = self.iface.addToolBar("Urbanomy")
        self.toolbar.setObjectName("UrbanomyToolbar")
        self.toolbar.setToolButtonStyle(Qt.ToolButtonTextBesideIcon)
        self.toolbar.setIconSize(QSize(20, 20))
        for text, label, slot in (("Установка Urbanomy…", "Установка", self.install_environment),
                                  ("Настройки Urbanomy…", "Настройки", self.configure),
                                  ("Рассчитать стоимость земли", "Стоимость", self.estimate),
                                  ("Оптимизировать выбранный квартал", "Оптимизация", self.optimize),
                                  ("Показать изменение стоимости", "Изменение стоимости", self.scenario_impact),
                                  ("Инвестиционная привлекательность", "Инвестиции", self.investment)):
            action = QAction(QIcon(os.path.join(self.directory, "icon.svg")), text,
                             self.iface.mainWindow())
            action.triggered.connect(slot)
            action.setIconText(label)
            self.iface.addPluginToMenu("Urbanomy", action)
            self.toolbar.addAction(action)
            self.actions.append(action)
        if self._needs_setup():
            QTimer.singleShot(0, self._welcome)

    def _needs_setup(self):
        # QSettings survives removal of a plugin. This installation's marker
        # does not, so a fresh ZIP install still opens the welcome/settings.
        return (not self.settings.value("Urbanomy/configured", False, type=bool)
                or not os.path.isfile(os.path.join(self.directory, ".urbanomy-configured")))

    def _mark_setup_complete(self):
        # The marker contains no settings or credentials and is excluded from
        # distributable ZIPs. A read-only plugin directory must not block setup.
        try:
            descriptor = os.open(os.path.join(self.directory, ".urbanomy-configured"),
                                 os.O_WRONLY | os.O_CREAT, 0o600)
            os.close(descriptor)
        except OSError:
            pass

    def _welcome(self):
        if self.alive:
            python_path = self._configuration()["python_path"]
            if not os.path.isfile(python_path) or not os.access(python_path, os.X_OK):
                if not self.install_environment():
                    return
            self.configure()

    def unload(self):
        self.alive = False
        if self.installer is not None:
            self.installer.reject()
        if self.llm_check is not None:
            self.llm_check.reject()
        self._cancel()
        for action in self.actions:
            self.iface.removePluginMenu("Urbanomy", action)
            self.toolbar.removeAction(action)
        self.toolbar.deleteLater()
        for dialog in list(self.result_dialogs):
            dialog.close()

    def _defaults(self):
        try:
            with open(os.path.join(self.directory, "runtime_defaults.json"), encoding="utf-8") as handle:
                defaults = json.load(handle)
            if defaults.get("model_path") and not os.path.isabs(defaults["model_path"]):
                defaults["model_path"] = os.path.join(self.directory, defaults["model_path"])
            return defaults
        except (OSError, ValueError):
            # Source checkout; the ZIP builder also embeds these local defaults.
            root = os.path.abspath(os.path.join(self.directory, "..", ".."))
            return {"python_path": os.path.join(root, ".venv", "bin", "python"),
                    "model_path": os.path.join(root, "examples", "data",
                                               "catboost_land_value_no_services.cbm")}

    def _configuration(self):
        defaults = self._defaults()
        config = {}
        for key in ("model_path", "python_path", "venv_path", "llm_base_url", "llm_model"):
            value = self.settings.value("Urbanomy/" + key, defaults.get(key, ""))
            config[key] = str(value or "")
        if config["venv_path"]:
            config["venv_path"] = os.path.abspath(os.path.expanduser(config["venv_path"]))
            if environment_directory(config["python_path"]) != config["venv_path"]:
                config["python_path"] = environment_python(config["venv_path"])
        else:
            # Settings from older plugin versions contain only the executable.
            config["venv_path"] = environment_directory(config["python_path"])
        if not os.path.isfile(config["python_path"]):
            target = default_environment_directory()
            marker = read_installation_marker(target)
            if marker and marker.get("complete") and os.path.isfile(environment_python(target)):
                config["python_path"] = environment_python(target)
                config["venv_path"] = target
        if not os.path.isfile(config["model_path"]) and os.path.isfile(defaults.get("model_path", "")):
            config["model_path"] = defaults["model_path"]
        config["api_key"] = self.api_key
        return config

    def configure(self):
        if self.process is not None or self.llm_check is not None:
            return
        dialog = SettingsDialog(self.iface.mainWindow(), self._configuration(), self._defaults(),
                                check_llm_callback=self.check_llm)
        if dialog.exec_() != QDialog.Accepted:
            dialog.deleteLater()
            return
        config = dialog.values()
        dialog.deleteLater()
        self.api_key = config.pop("api_key", "")
        for key, value in config.items():
            self.settings.setValue("Urbanomy/" + key, value)
        self.settings.setValue("Urbanomy/configured", True)
        # Never persist a key, including any value from an older installation.
        self.settings.remove("Urbanomy/api_key")
        self._mark_setup_complete()

    def install_environment(self):
        if (self.process is not None or self.installer is not None
                or self.llm_check is not None or not self.alive):
            return None
        dialog = InstallerDialog(self.iface.mainWindow(), self.directory,
                                 self._configuration()["python_path"])
        self.installer = dialog
        try:
            if dialog.exec_() != QDialog.Accepted or not self.alive:
                return None
            python_path = dialog.python_path
            self.settings.setValue("Urbanomy/python_path", python_path)
            venv_path = environment_directory(python_path)
            self.settings.setValue("Urbanomy/venv_path", venv_path)
            self.iface.messageBar().pushInfo("Urbanomy", "Urbanomy готова к работе: {}".format(venv_path))
            return python_path
        finally:
            self.installer = None
            dialog.deleteLater()

    def check_llm(self, configuration=None, parent=None):
        """Check saved settings or the current, unsaved settings form once."""
        if (self.process is not None or self.installer is not None
                or self.llm_check is not None or not self.alive):
            return
        config = dict(configuration) if configuration is not None else self._configuration()
        if configuration is None:
            # Unsaved form fields are validated as entered; direct calls share
            # the defaults shown when settings have not been saved yet.
            config["llm_base_url"] = config.get("llm_base_url") or "https://routerai.ru/api/v1"
            config["llm_model"] = config.get("llm_model") or "deepseek/deepseek-v4-flash"
        dialog = None
        try:
            dialog = LLMCheckDialog(parent or self.iface.mainWindow(), config, self.directory)
            self.llm_check = dialog
            dialog.exec_()
        except Exception as error:
            message = str(error)
            if config.get("api_key"):
                message = message.replace(config["api_key"], "[API key скрыт]")
            self._error(message)
        finally:
            self.llm_check = None
            if dialog is not None:
                dialog.deleteLater()

    def _ready(self):
        if self.process is not None or self.llm_check is not None:
            return False
        if not self.settings.value("Urbanomy/configured", False, type=bool):
            self._welcome()
        else:
            python_path = self._configuration()["python_path"]
            if not os.path.isfile(python_path) or not os.access(python_path, os.X_OK):
                if not self.install_environment():
                    return False
        return self.settings.value("Urbanomy/configured", False, type=bool)

    def _layer(self):
        layer = self.iface.activeLayer()
        if not isinstance(layer, QgsVectorLayer) or not layer.isValid():
            raise ValueError("Выберите в панели слоёв векторный слой кварталов.")
        if layer.geometryType() != QgsWkbTypes.PolygonGeometry:
            raise ValueError("Нужен слой полигонов кварталов.")
        if not layer.crs().isValid():
            raise ValueError("Укажите систему координат слоя.")
        if layer.featureCount() < 1:
            raise ValueError("Слой кварталов пуст.")
        if FID_FIELD in [field.name() for field in layer.fields()]:
            raise ValueError("Поле {} зарезервировано Urbanomy.".format(FID_FIELD))
        return layer

    def _metric_crs(self, layer):
        # Use the same local UTM projection for the constraints and the worker.
        transform = QgsCoordinateTransform(layer.crs(), QgsCoordinateReferenceSystem("EPSG:4326"),
                                           QgsProject.instance())
        extent = transform.transformBoundingBox(layer.extent())
        point = extent.center()
        zone = max(1, min(60, int(math.floor((point.x() + 180.0) / 6.0)) + 1))
        if not -80.0 <= point.y() <= 84.0:
            raise ValueError("Для этих широт нужна отдельная метрическая проекция.")
        return QgsCoordinateReferenceSystem("EPSG:{}".format((32600 if point.y() >= 0 else 32700) + zone))

    def _site_area(self, layer, feature, metric_crs):
        geometry = QgsGeometry(feature.geometry())
        geometry.transform(QgsCoordinateTransform(layer.crs(), metric_crs, QgsProject.instance()))
        area = geometry.area()
        if not math.isfinite(area) or area <= 0:
            raise ValueError("У выбранного квартала отсутствует корректная площадь.")
        return area

    def estimate(self):
        if not self._ready():
            return
        try:
            layer = self._layer()
            dialog = EstimateDialog(self.iface.mainWindow(), [field.name() for field in layer.fields()])
            try:
                if dialog.exec_() == QDialog.Accepted:
                    self._start("estimate", layer, dialog.values())
            finally:
                dialog.deleteLater()
        except Exception as error:
            self._error(str(error))

    def optimize(self):
        if not self._ready():
            return
        try:
            layer = self._layer()
            selected = layer.selectedFeatures()
            if len(selected) != 1:
                raise ValueError("Выделите ровно один квартал на карте для оптимизации.")
            metric_crs = self._metric_crs(layer)
            constraints = ConstraintsDialog(self.iface.mainWindow(),
                                            self._site_area(layer, selected[0], metric_crs))
            if constraints.exec_() != QDialog.Accepted:
                return
            parameters = OptimizerDialog(self.iface.mainWindow(), bool(self.api_key))
            if parameters.exec_() != QDialog.Accepted:
                return
            options = parameters.values()
            if self.investment_parameters is not None:
                options["investment_parameters"] = self.investment_parameters
            options["constraints"] = constraints.values()
            options["selected_fids"] = [int(selected[0].id())]
            self._start("optimize", layer, options, metric_crs)
        except Exception as error:
            self._error(str(error))

    def scenario_impact(self):
        if not self._ready():
            return
        try:
            layer = self._layer()
            selected = layer.selectedFeatureIds()
            if len(selected) != 1:
                raise ValueError("Выделите ровно один изменённый квартал на карте.")
            columns = [field.name() for field in layer.fields() if field.isNumeric()]
            if not columns:
                raise ValueError("Сначала рассчитайте стоимость земли, затем измените параметры квартала.")
            column, accepted = QInputDialog.getItem(
                self.iface.mainWindow(), "Изменение стоимости",
                "Столбец полной стоимости ДО изменения, руб. (не стоимость сотки):",
                columns, columns.index("land_value") if "land_value" in columns else 0, False)
            if accepted:
                self._start("impact", layer, {"before_column": column, "selected_fids": selected})
        except Exception as error:
            self._error(str(error))

    def investment(self):
        if not self._ready():
            return
        try:
            layer = self._layer()
            selected = list(layer.selectedFeatureIds())
            if len(selected) != 1:
                raise ValueError("Выделите ровно один квартал на карте для расчёта инвестиционной привлекательности.")
            dialog = InvestmentDialog(self.iface.mainWindow(), self.investment_parameters)
            try:
                if dialog.exec_() == QDialog.Accepted:
                    options = dialog.values()
                    self.investment_parameters = options["investment_parameters"]
                    self._start("investment", layer, dict(options, selected_fids=selected))
            finally:
                dialog.deleteLater()
        except Exception as error:
            self._error(str(error))

    def _snapshot(self, layer):
        names = [field.name() for field in layer.fields()]
        features = []
        for feature in layer.getFeatures():
            geometry = feature.geometry()
            if geometry.isEmpty():
                raise ValueError("Квартал FID {} имеет пустую геометрию.".format(feature.id()))
            properties = {name: json_value(value) for name, value in zip(names, feature.attributes())}
            properties[FID_FIELD] = int(feature.id())
            features.append({"type": "Feature", "properties": properties,
                             "geometry": json.loads(geometry.asJson(15))})
        features.sort(key=lambda feature: feature["properties"][FID_FIELD])
        return {"type": "FeatureCollection", "features": features,
                "crs": {"type": "name", "properties": {"name": layer.crs().authid() or layer.crs().toWkt()}}}

    def _start(self, operation, layer, options=None, metric_crs=None):
        config = self._configuration()
        if not os.path.isfile(config["python_path"]) or not os.access(config["python_path"], os.X_OK):
            raise ValueError("Укажите исполняемый Python окружения Urbanomy в настройках.")
        if not os.path.isfile(config["model_path"]):
            raise ValueError("Файл модели CatBoost не найден. Проверьте настройки.")
        if operation in ("estimate", "optimize"):
            caps = layer.dataProvider().capabilities()
            required = QgsVectorDataProvider.ChangeAttributeValues | QgsVectorDataProvider.AddAttributes
            if caps & required != required or layer.readOnly():
                raise ValueError("Слой не поддерживает изменение атрибутов. Сохраните его в GeoPackage.")
            if layer.storageType().lower().find("shapefile") >= 0:
                raise ValueError("Сохраните слой в GeoPackage или GeoJSON для длинных имён атрибутов.")
        data = self._snapshot(layer)
        metric_crs = metric_crs or self._metric_crs(layer)
        temporary = tempfile.mkdtemp(prefix="urbanomy_")
        try:
            input_path = os.path.join(temporary, "blocks.geojson")
            request_path = os.path.join(temporary, "request.json")
            response_path = os.path.join(temporary, "response.json")
            request = {"operation": operation, "data_path": input_path,
                       "crs": layer.crs().authid() or layer.crs().toWkt(),
                       "metric_crs": metric_crs.authid(), "model_path": config["model_path"]}
            request.update(options or {})
            if request.get("use_llm") and self.api_key:
                request["llm"] = {"base_url": config["llm_base_url"],
                                  "model": config["llm_model"]}
            else:
                request["prompt"] = ""
            for path, payload in ((input_path, data), (request_path, request)):
                descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
                with os.fdopen(descriptor, "w", encoding="utf-8") as handle:
                    json.dump(payload, handle, ensure_ascii=False, allow_nan=False)
            self.job = {"operation": operation, "layer_id": layer.id(), "layer": layer,
                        "fingerprint": fingerprint(data), "temporary": temporary,
                        "response_path": response_path, "cancelled": False,
                        "all_fids": [item["properties"][FID_FIELD] for item in data["features"]],
                        "selected_fids": request.get("selected_fids", []),
                        "price_fields": request.get("price_fields"),
                        "show_scenario_impact": request.get("show_scenario_impact", False),
                        "n_gen": request.get("n_gen", 20), "completed_generations": 0,
                        "current_generation": 0, "stdout_buffer": b"",
                        "stdout_discard": False, "generation_stats": ""}
            process = QProcess(self.iface.mainWindow())
            environment = QProcessEnvironment.systemEnvironment()
            # QGIS may set its own PYTHONHOME/PYTHONPATH; never pass those to the venv.
            for key in ("PYTHONHOME", "PYTHONPATH", "QT_PLUGIN_PATH", "QGIS_PREFIX_PATH", "URBANOMY_API_KEY"):
                environment.remove(key)
            bundled = os.path.join(self.directory, "backend", "src")
            source = bundled if os.path.isdir(bundled) else os.path.abspath(os.path.join(self.directory, "..", "..", "src"))
            environment.insert("PYTHONPATH", source)
            environment.insert("PYTHONUNBUFFERED", "1")
            cache = os.path.join(tempfile.gettempdir(), "urbanomy-qgis-cache")
            environment.insert("MPLCONFIGDIR", os.path.join(cache, "matplotlib"))
            environment.insert("XDG_CACHE_HOME", cache)
            if request.get("use_llm") and self.api_key:
                environment.insert("URBANOMY_API_KEY", self.api_key)
            process.setProcessEnvironment(environment)
            process.setWorkingDirectory(temporary)
            process.setProcessChannelMode(QProcess.MergedChannels)
            process.readyReadStandardOutput.connect(self._drain_output)
            process.errorOccurred.connect(self._process_error)
            process.finished.connect(self._finished)
            self.process = process
            label = ("Подготовка данных для оптимизации…" if operation == "optimize"
                     else "Urbanomy: выполняется расчёт…")
            self.progress = QProgressDialog(label, "Отмена", 0, 0,
                                            self.iface.mainWindow())
            self.progress.setWindowTitle("Urbanomy")
            self.progress.setMinimumDuration(0)
            self.progress.setAutoClose(False)
            self.progress.setAutoReset(False)
            self.progress.canceled.connect(self._cancel)
            self.progress.show()
            for action in self.actions:
                action.setEnabled(False)
            process.start(config["python_path"], ["-m", "urbanomy.qgis_backend", request_path, response_path])
        except Exception:
            if self.process is None:
                self.job = None
                shutil.rmtree(temporary)
            else:
                self._cancel()
            raise

    def _drain_output(self):
        # Only the numeric progress protocol reaches the UI. Library logs and
        # errors can contain credentials and are always discarded.
        if self.process is None:
            return
        job = self.job
        if not job or job.get("cancelled"):
            return
        output = bytes(self.process.readAllStandardOutput())
        if job["operation"] != "optimize":
            return
        maximum_line = 16384
        lines = (job.get("stdout_buffer", b"") + output).split(b"\n")
        tail = lines.pop()
        discard = job.get("stdout_discard", False)
        for index, line in enumerate(lines):
            if (discard and index == 0) or len(line) > maximum_line:
                continue
            if not line.startswith(b"URBANOMY_PROGRESS "):
                continue
            try:
                event = json.loads(line[len(b"URBANOMY_PROGRESS "):].decode("utf-8"))
                self._update_progress(event)
            except (ValueError, TypeError, UnicodeDecodeError):
                pass
        if (discard and not lines) or len(tail) > maximum_line:
            job["stdout_buffer"], job["stdout_discard"] = b"", True
        else:
            job["stdout_buffer"], job["stdout_discard"] = tail, False

    def _update_progress(self, event):
        """Accept a bounded numerical event, never arbitrary worker text."""
        job, progress = self.job, self.progress
        if (not job or not progress or job["operation"] != "optimize"
                or job.get("cancelled") or not isinstance(event, dict)):
            return
        required = {"version", "operation", "phase", "generation", "n_gen", "evaluations"}
        metric_groups = (("land_min", "land_median", "land_max"),
                         ("npv_min", "npv_median", "npv_max"),
                         ("ser_min", "ser_median", "ser_max"))
        allowed = required | {"population"} | {key for group in metric_groups for key in group}
        if not required <= set(event) or set(event) - allowed:
            return
        if (type(event["version"]) is not int or event["version"] != 1
                or event["operation"] != "optimize"
                or event["phase"] not in ("prepare", "start", "generation", "finalize", "fixed")):
            return
        generation, total, evaluations = event["generation"], event["n_gen"], event["evaluations"]
        if (type(total) is not int or total != job.get("n_gen") or not 1 <= total <= 10000
                or type(generation) is not int or not 0 <= generation <= total
                or type(evaluations) is not int or not 0 <= evaluations <= 10 ** 12):
            return
        if "population" in event and (type(event["population"]) is not int
                                      or not 0 <= event["population"] <= 10000):
            return
        for group in metric_groups:
            present = [key in event for key in group]
            if any(present) and not all(present):
                return
            for key in group:
                if key not in event:
                    continue
                value = event[key]
                if type(value) not in (int, float):
                    return
                try:
                    finite = math.isfinite(value)
                except OverflowError:
                    return
                if not finite or (key.startswith("ser_") and not 0.0 <= value <= 1.0):
                    return
        phase = event["phase"]
        completed = job.get("completed_generations", 0)
        current = job.get("current_generation", 0)
        if (generation < completed
                or (phase == "start" and (generation <= completed or generation < current))):
            return
        if phase == "prepare":
            if generation != 0 or current:
                return
            progress.setLabelText("Подготовка данных для оптимизации…")
            return
        if phase in ("start", "generation") and generation < 1:
            return
        if phase == "generation" and generation <= completed:
            return
        if phase == "fixed" and (generation != 0 or evaluations > 1):
            return
        if job.get("fixed_scenario") and phase not in ("fixed", "finalize"):
            return
        stats = []
        for group, title, decimals in zip(metric_groups,
                                         ("Стоимость земли слоя, руб.", "NPV инвестора, руб.", "Оценка LLM"),
                                         (0, 0, 3)):
            if all(key in event for key in group):
                numbers = [format(event[key], ",.{}f".format(decimals)).replace(",", " ")
                           for key in group]
                stats.append("{}: {} / {} / {}".format(title, *numbers))
        if stats:
            job["generation_stats"] = "Мин. / медиана / макс.:\n" + "\n".join(stats)
        if phase == "fixed":
            job["fixed_scenario"] = True
            progress.setRange(0, 1)
            progress.setValue(evaluations)
            label = ("Все параметры фиксированы: оценён единственный сценарий." if evaluations
                     else "Все параметры фиксированы. Оценка единственного сценария…")
        elif job.get("fixed_scenario"):
            progress.setRange(0, 1)
            progress.setValue(1)
            label = "Единственный сценарий оценён. Проверка и применение результата…"
        else:
            progress.setRange(0, total)
            if phase == "generation":
                job["completed_generations"] = generation
                job["current_generation"] = max(current, generation)
                progress.setValue(generation)
                label = "Завершено поколение {} из {}.".format(generation, total)
            elif phase == "start":
                job["current_generation"] = generation
                progress.setValue(completed)
                label = "Выполняется поколение {} из {}.".format(generation, total)
            else:
                progress.setValue(completed)
                label = "Оптимизация завершена. Проверка и применение результата…"
        label += "\nПроверено уникальных вариантов: {}.".format(evaluations)
        if "population" in event:
            label += " В популяции: {}.".format(event["population"])
        if job.get("generation_stats"):
            label += "\n" + job["generation_stats"]
        progress.setLabelText(label)

    def _process_error(self, error):
        if self.process is not None and error == QProcess.FailedToStart:
            self._error("Не удалось запустить Python. Проверьте путь в настройках Urbanomy.")
            self._cleanup()

    def _cancel(self):
        process = self.process
        if process is not None:
            self.job["cancelled"] = True
            process.kill()
            process.waitForFinished(1000)
            if self.process is process and process.state() == QProcess.NotRunning:
                self._cleanup()

    def _finished(self, exit_code, exit_status):
        if self.job is None:
            return
        self._drain_output()
        job = self.job
        try:
            if job["cancelled"] or not self.alive:
                return
            if not os.path.isfile(job["response_path"]):
                raise ValueError("Python завершился без результата. Проверьте Python ≥3.10 и установку зависимостей Urbanomy.")
            with open(job["response_path"], encoding="utf-8") as handle:
                response = json.load(handle)
            if not response.get("ok"):
                raise ValueError(response.get("error") or "Ошибка вычисления Urbanomy.")
            if exit_code != 0 or exit_status != QProcess.NormalExit:
                raise ValueError("Вычислитель завершился с ошибкой; результат не применён.")
            layer = QgsProject.instance().mapLayer(job["layer_id"])
            if layer is None or layer is not job["layer"]:
                raise ValueError("Исходный слой был удалён. Результат не применён.")
            if fingerprint(self._snapshot(layer)) != job["fingerprint"]:
                raise ValueError("Атрибуты или геометрия слоя изменились во время расчёта. Запустите расчёт ещё раз.")
            operation = job["operation"]
            expected = job["selected_fids"] if operation in ("optimize", "investment") and job["selected_fids"] else job["all_fids"]
            validate_result_rows(response.get("rows"), expected)
            impact = None
            if operation == "impact" or (operation == "optimize" and job.get("show_scenario_impact")):
                impact_rows = response.get("rows") if operation == "impact" else response.get("impact_rows")
                validate_result_rows(impact_rows, job["all_fids"])
                impact = self._impact_layer(layer, impact_rows, job["selected_fids"][0])
            if operation == "investment":
                self._show_results("Инвестиционная привлекательность", response)
            elif operation == "impact":
                self._show_impact(layer, impact)
            else:
                self._apply(layer, response, operation)
                if operation == "optimize":
                    if impact is not None:
                        self._show_impact(layer, impact)
                    self._show_results("Результат оптимизации квартала", response)
                message = "Результат применён. Сохраните правки слоя; отмена доступна через Ctrl+Z / ⌘Z."
                self.iface.messageBar().pushInfo("Urbanomy", message)
        except Exception as error:
            self._error(str(error))
        finally:
            self._cleanup()

    def _apply(self, layer, response, operation):
        rows = response["rows"]
        aliases = {}
        if operation == "estimate":
            fields = self.job.get("price_fields") if self.job else None
            total_field, unit_field = next_price_fields(
                [field.name() for field in layer.fields()],
                **(fields or {}))
            for row in rows:
                attributes = row["attributes"]
                if set(attributes) != {"land_value", "land_value_per_100m2", "site_area"}:
                    raise ValueError("Некорректные поля расчёта стоимости.")
                row["attributes"] = {"site_area": attributes["site_area"]}
                if total_field is not None:
                    row["attributes"][total_field] = attributes["land_value"]
                if unit_field is not None:
                    row["attributes"][unit_field] = attributes["land_value_per_100m2"]
            if total_field is not None:
                aliases[total_field] = "Стоимость земли, руб. ({})".format(total_field)
            if unit_field is not None:
                aliases[unit_field] = "Стоимость сотки, руб. ({})".format(unit_field)
        else:
            allowed = {"residential", "business", "recreation", "industrial", "transport", "special",
                       "agriculture", "land_use", "share", "footprint_area", "build_floor_area",
                       "living_area", "non_living_area", "population", "site_area", "fsi", "gsi",
                       "mxi", "l", "morphotype", "land_use_before", "build_floor_area_before", "land_value_before"}
            if any(set(row["attributes"]) - allowed for row in rows):
                raise ValueError("Вычислитель вернул неизвестные поля сценария.")
        new_fields = {}
        current = layer.fields()
        for row in rows:
            for name, value in row["attributes"].items():
                if name not in new_fields and current.indexFromName(name) < 0:
                    new_fields[name] = QgsField(name, QVariant.String if isinstance(value, str) else QVariant.Double)
                index = current.indexFromName(name)
                if index >= 0 and isinstance(value, float) and not value.is_integer():
                    if current[index].type() in (QVariant.Int, QVariant.UInt, QVariant.LongLong, QVariant.ULongLong):
                        raise ValueError("Поле {} имеет целочисленный тип. Измените его на десятичный для оптимизации.".format(name))
        started_here = not layer.isEditable()
        if started_here and not layer.startEditing():
            raise ValueError("Не удалось открыть слой для редактирования.")
        layer.beginEditCommand("Urbanomy: {}".format(operation))
        try:
            for field in new_fields.values():
                if not layer.addAttribute(field):
                    raise ValueError("Не удалось добавить поле {}.".format(field.name()))
            layer.updateFields()
            for row in rows:
                for name, value in row["attributes"].items():
                    index = layer.fields().indexFromName(name)
                    if index < 0 or not layer.changeAttributeValue(row["fid"], index, value, QVariant(), True):
                        raise ValueError("Не удалось обновить поле {} квартала {}.".format(name, row["fid"]))
            layer.endEditCommand()
        except Exception:
            layer.destroyEditCommand()
            if started_here:
                layer.rollBack()
            raise
        for name, alias in aliases.items():
            layer.setFieldAlias(layer.fields().indexFromName(name), alias)
        layer.triggerRepaint()

    def _impact_layer(self, source, rows, target_fid):
        columns = ("land_value_before", "land_value", "d_rub", "land_value_delta_pct")
        for row in rows:
            attributes = row["attributes"]
            if (set(attributes) != set(columns)
                    or any(not isinstance(attributes[name], (int, float)) for name in columns[:3])
                    or (attributes[columns[3]] is not None
                        and not isinstance(attributes[columns[3]], (int, float)))):
                raise ValueError("Некорректные поля изменения стоимости.")
        impact = QgsVectorLayer(QgsWkbTypes.displayString(source.wkbType()),
                                "Изменение стоимости — {}".format(source.name()), "memory")
        impact.setCrs(source.crs())
        provider = impact.dataProvider()
        if not impact.isValid() or not provider.addAttributes(
                [QgsField("source_fid", QVariant.LongLong)] + [QgsField(name, QVariant.Double) for name in columns]):
            raise ValueError("Не удалось создать слой изменения стоимости.")
        impact.updateFields()
        values = {row["fid"]: row["attributes"] for row in rows}
        features = []
        for original in source.getFeatures():
            feature = QgsFeature(impact.fields())
            feature.setGeometry(original.geometry())
            feature.setAttributes([original.id()] + [values[original.id()][name] for name in columns])
            features.append(feature)
        if not provider.addFeatures(features)[0]:
            raise ValueError("Не удалось добавить кварталы в слой изменения стоимости.")
        impact.updateExtents()
        for name, alias in zip(columns, ("Стоимость до, руб.", "Стоимость после, руб.",
                                         "Изменение стоимости, руб.", "Изменение стоимости, %")):
            impact.setFieldAlias(impact.fields().indexFromName(name), alias)
        renderer = QgsRuleBasedRenderer(QgsFillSymbol.createSimple({}))
        root = renderer.rootRule()
        root.removeChildAt(0)
        # Same coolwarm direction and fixed ±20% scale as plot_scenario_impact.
        for expression, color, label in (
            ('abs("d_rub") <= 1e-9', "lightgrey", "Без изменений"),
            ('"land_value_delta_pct" IS NULL', "#888888", "Процент не определён (стоимость до = 0)"),
            ('"land_value_delta_pct" <= -20', "#3b4cc0", "−20% и ниже"),
            ('"land_value_delta_pct" > -20 AND "land_value_delta_pct" <= -10', "#8db0fe", "От −20 до −10%"),
            ('"land_value_delta_pct" > -10 AND "land_value_delta_pct" < 0', "#c0d4f5", "От −10 до 0%"),
            ('"land_value_delta_pct" >= 0 AND "land_value_delta_pct" < 10', "#f2cbb7", "От 0 до +10%"),
            ('"land_value_delta_pct" >= 10 AND "land_value_delta_pct" < 20', "#f4987a", "От +10 до +20%"),
            ('"land_value_delta_pct" >= 20', "#b40426", "+20% и выше"),
        ):
            rule = QgsRuleBasedRenderer.Rule(QgsFillSymbol.createSimple(
                {"color": color, "outline_color": "white", "outline_width": "0.2"}))
            rule.setFilterExpression('abs("d_rub") > 1e-9 AND ({})'.format(expression)
                                     if "land_value_delta_pct" in expression else expression)
            rule.setLabel(label)
            root.appendChild(rule)
        target = QgsRuleBasedRenderer.Rule(QgsFillSymbol.createSimple(
            {"style": "no", "outline_color": "red", "outline_width": "0.8"}))
        target.setFilterExpression('"source_fid" = {}'.format(int(target_fid)))
        target.setLabel("Изменяемый квартал")
        root.appendChild(target)
        impact.setRenderer(renderer)
        return impact

    def _show_impact(self, source, impact):
        QgsProject.instance().addMapLayer(impact)
        self.iface.setActiveLayer(source)
        self.iface.mapCanvas().refresh()
        self.iface.messageBar().pushInfo(
            "Urbanomy", "Карта изменения стоимости добавлена. Слой временный: сохраните его в GeoPackage для дальнейшей работы.")

    def _show_results(self, title, response):
        dialog = ResultsDialog(self.iface.mainWindow(), title, response)
        dialog.setAttribute(Qt.WA_DeleteOnClose, True)
        self.result_dialogs.append(dialog)
        dialog.finished.connect(lambda result: self.result_dialogs.remove(dialog)
                                if dialog in self.result_dialogs else None)
        dialog.show()

    def _cleanup(self):
        progress, process, job = self.progress, self.process, self.job
        self.progress, self.process, self.job = None, None, None
        if progress is not None:
            # QProgressDialog.closeEvent emits canceled even on normal completion.
            progress.blockSignals(True)
            progress.close()
            progress.deleteLater()
        if process is not None:
            process.blockSignals(True)
            process.deleteLater()
        if job is not None:
            shutil.rmtree(job["temporary"], ignore_errors=True)
        for action in self.actions:
            action.setEnabled(True)

    def _error(self, message):
        if self.api_key:
            message = message.replace(self.api_key, "[API key скрыт]")
        dialog = QMessageBox(QMessageBox.Warning, "Urbanomy", message,
                            QMessageBox.Ok, self.iface.mainWindow())
        dialog.setTextFormat(Qt.PlainText)
        dialog.exec_()
